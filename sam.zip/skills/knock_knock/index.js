function * knockJoke(query) {

var knockknock = require('knock-knock-jokes')

    return {text: knockknock()}
}

const intent = () => ({
    keywords: ["knock knock"], module: 'knock_knock'
})

const examples = () => (
    []
)

module.exports = {
    get: knockJoke,
    intent,
    examples
}
