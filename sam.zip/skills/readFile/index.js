function hardRule(query, breakdown) {
    return query.startsWith('read to me') || query.startsWith('read to me file') || query.startsWith('read me file') || query.startsWith('read file') || query.startsWith('read file to me') || query.startsWith('open file')
}


function* read_file(query) {

    let fs = require('fs');
    let fileName = "abc.txt";
    let directoryName = "./file_directory_created_by_sam/";
    let contents = "";
    let lastThreeChar = "";


    if (query.includes('read to me') || query.includes('read file to me')) {

        query = query.split('me')[1].trim();
        lastThreeChar = query.substr(query.length - 3);
        if (lastThreeChar == "txt" || lastThreeChar == "doc") {
            query = query.slice(0, -3);
            fileName = query;
        } else {
            fileName = query;
        }

        console.log("lastThreeChar : " + lastThreeChar);

        if (lastThreeChar == "txt") {

            if (fs.existsSync(directoryName + fileName + ".txt")) {
                console.log('Found file');
                contents = fs.readFileSync(directoryName + fileName + ".txt", 'utf8');
                console.log("The content of the file is: " + contents);

            } else {
                return {
                    text: "File not found"
                }

            }



        } else if (lastThreeChar == "doc") {

            if (fs.existsSync(directoryName + fileName + ".doc")) {
                console.log('Found file');
                contents = fs.readFileSync(directoryName + fileName + ".doc", 'utf8');
                console.log("The content of the file is: " + contents);

            } else {
                return {
                    text: "File not found"
                }

            }

        } else {

            if (fs.existsSync(directoryName + fileName + ".txt")) {
                console.log('Found file');
                contents = fs.readFileSync(directoryName + fileName + ".txt", 'utf8');
                console.log("The content of the file is: " + contents);

            } else {
                return {
                    text: "File not found"
                }

            }

        }

    } else if (query.includes('read to me file') || query.includes('read me file') || query.includes('read file') || query.startsWith('open file')) {

        query = query.split('file')[1].trim();
        lastThreeChar = query.substr(query.length - 3);

        if (lastThreeChar == "txt" || lastThreeChar == "doc") {
            query = query.slice(0, -3);
            fileName = query;
        } else {
            fileName = query;
        }

        console.log("lastThreeChar : " + lastThreeChar);

        if (lastThreeChar == "txt") {

            if (fs.existsSync(directoryName + fileName + ".txt")) {
                console.log('Found file');
                contents = fs.readFileSync(directoryName + fileName + ".txt", 'utf8');
                console.log("The content of the file is: " + contents);

            } else {
                return {
                    text: "File not found"
                }

            }


        } else if (lastThreeChar == "doc") {

            if (fs.existsSync(directoryName + fileName + ".doc")) {
                console.log('Found file');
                contents = fs.readFileSync(directoryName + fileName + ".doc", 'utf8');
                console.log("The content of the file is: " + contents);

            } else {
                return {
                    text: "File not found"
                }

            }

        } else {

            if (fs.existsSync(directoryName + fileName + ".txt")) {
                console.log('Found file');
                contents = fs.readFileSync(directoryName + fileName + ".txt", 'utf8');
                console.log("The content of the file is: " + contents);

            } else {
                return {
                    text: "File not found"
                }

            }

        }



    }

    return {
        text: "The content of the file is: " + contents
    }
}

const intent = () => ({
    keywords: [],
    module: 'readFile'
})

const examples = () => (
    []
)

module.exports = {
    get: read_file,
    hardRule,
    examples
}
