function* twitter_resp(query) {

    query = query.split('tweet')[1].trim();
    var Twitter = require('twitter');

    var client = new Twitter({
        consumer_key: '2r1qTLEiD7wZDcMYKYjYktUk4',
        consumer_secret: 'F9wvQ9E4tCljqsRmxH44Y4QiQW21J5pHiv0BGTzLgQkapIVZw3',
        access_token_key: '878628328965455874-iuGdoaGfKM8l7zWKGr5lRvCgIoXvxmF',
        access_token_secret: 'Vz838vasZuXSvcFcsy7sdFBugOUIUJ6Ue687ZVqQkLKLr'
    });


    client.post('statuses/update', {
        status: query
    }, function(error, tweet, response) {
        if (!error) {
            console.log(tweet);
        }
    });


    return {
        text: "Tweet Successfully Posted"
    }

}

const intent = () => ({
    keywords: ["tweet"],
    module: 'twitter'
})

const examples = () => (
    ["tweet"]
)

module.exports = {
    get: twitter_resp,
    intent,
    examples
}
