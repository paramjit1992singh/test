function hardRule(query, breakdown) {
    return query.startsWith('create a file') || query.startsWith('create file') || query.startsWith('make a file') || query.startsWith('write a file') || query.startsWith('create a text file') || query.startsWith('make a text file') || query.startsWith('write a text file') || query.startsWith('create a document') || query.startsWith('make a document') || query.startsWith('write a document') || query.startsWith('write into a file') || query.startsWith('write into a document') || query.startsWith('document this') || query.startsWith('document into a file')
}

function* document(query) {

    let fs = require('fs');
    let fileName = "new_text_file_createdby_sam";
    let content = "abc";
    let directoryName = "./file_directory_created_by_sam";
    let files = [];
    let lastThreeChar = "";

    if (query.startsWith('create a file') || query.startsWith('create file') || query.startsWith('make a file') || query.startsWith('write a file') || query.startsWith('create a text file') || query.startsWith('make a text file') || query.startsWith('write a text file') || query.startsWith('write into a file')) {


        if (query.includes('with filename') || query.includes('with document name') || query.includes('filename') || query.includes('document name')) {

            query = query.split('name')[1].trim();

            if (query.includes('and content')) {

                fileName = query.split('and content')[0].trim();

                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "txt") {
                    fileName = fileName.slice(0, -3);

                }

                content = query.split('and content')[1].trim();

            } else if (query.includes('content')) {

                fileName = query.split('content')[0].trim();

                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "txt") {
                    fileName = fileName.slice(0, -3);

                }

                content = query.split('content')[1].trim();

            } else if (query.includes('and file content') || query.includes('and document content')) {


                if (query.includes('and file content')) {

                    fileName = query.split('and file content')[0].trim();

                } else if (query.includes('and document content')) {

                    fileName = query.split('and document content')[0].trim();

                } else {

                    fileName = query.split('and file content')[0].trim();

                }

                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "txt") {
                    fileName = fileName.slice(0, -3);

                }

                if (query.includes('and file content')) {

                    content = query.split('and file content')[1].trim();

                } else if (query.includes('and document content')) {

                    content = query.split('and document content')[1].trim();

                } else {

                    content = query.split('and file content')[1].trim();
                }



            } else {

                fileName = query;

            }


        } else if (query.includes('where filename is') || query.includes('where document name is')) {

            query = query.split('is')[1].trim();

            if (query.includes('and content is')) {

                fileName = query.split('and content is')[0].trim();

                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "txt") {
                    fileName = fileName.slice(0, -3);

                }

                content = query.split('and content is')[1].trim();

            } else if (query.includes('and file content is') || query.includes('and document content is')) {

                if (query.includes('and file content is')) {

                    fileName = query.split('and file content is')[0].trim();

                } else if (query.includes('and document content is')) {

                    fileName = query.split('and document content is')[0].trim();

                } else {

                    fileName = query.split('and file content is')[0].trim();

                }


                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "txt") {
                    fileName = fileName.slice(0, -3);

                }


                if (query.includes('and file content is')) {

                    content = query.split('and file content is')[1].trim();

                } else if (query.includes('and document content is')) {

                    content = query.split('and document content is')[1].trim();

                } else {

                    content = query.split('and file content is')[1].trim();

                }



            } else {

                fileName = query;

            }



        } else if (query.includes('filename is') || query.includes('document name is')) {

            query = query.split('is')[1].trim();

            if (query.includes('content is')) {

                fileName = query.split('content is')[0].trim();

                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "txt") {
                    fileName = fileName.slice(0, -3);

                }

                content = query.split('content is')[1].trim();

            } else if (query.includes('file content is') || query.includes('document content is')) {


                if (query.includes('file content is')) {

                    fileName = query.split('file content is')[0].trim();

                } else if (query.includes('document content is')) {

                    fileName = query.split('document content is')[0].trim();

                } else {

                    fileName = query.split('file content is')[0].trim();

                }



                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "txt") {
                    fileName = fileName.slice(0, -3);

                }


                if (query.includes('file content is')) {

                    content = query.split('file content is')[1].trim();

                } else if (query.includes('document content is')) {

                    content = query.split('document content is')[1].trim();

                } else {

                    content = query.split('file content is')[1].trim();

                }




            } else {

                fileName = query;

            }


        } else {

            return {
                text: "Sir! Please tell what will be the file name and file content"
            }


        }


        fs.existsSync("file_directory_created_by_sam") || fs.mkdirSync("file_directory_created_by_sam");


        fs.writeFile("./file_directory_created_by_sam/" + fileName + '.txt', content, function(err) {
            if (err) return console.log(err);
            console.log('File created');
        });



        return {
            text: "Your file has been successfully saved at ./file_directory_created_by_sam"
        }


    } else if (query.startsWith('create a document') || query.startsWith('make a document') || query.startsWith('write a document') || query.startsWith('write into a document') || query.startsWith('document this') || query.startsWith('document into a file')) {


        if (query.includes('with document name') || query.includes('with file name')) {

            query = query.split('name')[1].trim();

            if (query.includes('and content')) {

                fileName = query.split('and content')[0].trim();

                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "doc") {
                    fileName = fileName.slice(0, -3);

                }

                content = query.split('and content')[1].trim();

            } else if (query.includes('and document content') || query.includes('and file content')) {

                if (query.includes('and file content')) {

                    fileName = query.split('and file content')[0].trim();

                } else if (query.includes('and document content')) {

                    fileName = query.split('and document content')[0].trim();

                } else {

                    fileName = query.split('and document content')[0].trim();

                }


                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "doc") {
                    fileName = fileName.slice(0, -3);

                }

                content = query.split('and document content')[1].trim();

            } else {

                fileName = query;

            }


        } else if (query.includes('where document name is') || query.includes('where file name is')) {

            query = query.split('is')[1].trim();

            if (query.includes('and content is')) {

                fileName = query.split('and content is')[0].trim();

                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "doc") {
                    fileName = fileName.slice(0, -3);

                }

                content = query.split('and content is')[1].trim();

            } else if (query.includes('and document content is') || query.includes('and file content is')) {


                if (query.includes('and file content is')) {

                    fileName = query.split('and file content is')[0].trim();

                } else if (query.includes('and document content is')) {

                    fileName = query.split('and document content is')[0].trim();

                } else {

                    fileName = query.split('and document content is')[0].trim();

                }




                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "doc") {
                    fileName = fileName.slice(0, -3);

                }


                if (query.includes('and file content is')) {

                    content = query.split('and file content is')[1].trim();

                } else if (query.includes('and document content is')) {

                    content = query.split('and document content is')[1].trim();

                } else {

                    content = query.split('and document content is')[1].trim();

                }




            } else {

                fileName = query;

            }



        } else if (query.includes('document name is') || query.includes('file name is')) {

            query = query.split('is')[1].trim();

            if (query.includes('content is')) {

                fileName = query.split('content is')[0].trim();

                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "doc") {
                    fileName = fileName.slice(0, -3);

                }

                content = query.split('content is')[1].trim();

            } else if (query.includes('document content is') || query.includes('file content is')) {

                if (query.includes('file content is')) {

                    fileName = query.split('file content is')[0].trim();

                } else if (query.includes('document content is')) {

                    fileName = query.split('document content is')[0].trim();

                } else {

                    fileName = query.split('document content is')[0].trim();

                }




                lastThreeChar = fileName.substr(query.length - 3);
                console.log("lastThreeChar: " + lastThreeChar);
                if (lastThreeChar == "doc") {
                    fileName = fileName.slice(0, -3);

                }


                if (query.includes('file content is')) {

                    content = query.split('file content is')[1].trim();

                } else if (query.includes('document content is')) {

                    content = query.split('document content is')[1].trim();

                } else {

                    content = query.split('document content is')[1].trim();

                }



            } else {

                fileName = query;

            }


        } else {

            return {
                text: "Sir! Please tell what will be the document name and document content"
            }


        }


        fs.existsSync("file_directory_created_by_sam") || fs.mkdirSync("file_directory_created_by_sam");


        fs.writeFile("./file_directory_created_by_sam/" + fileName + '.doc', content, function(err) {
            if (err) return console.log(err);
            console.log('File created');
        });



        return {
            text: "Your document has been successfully saved at ./file_directory_created_by_sam"
        }


    } else {
        return {
            text: "This feature is under development"
        }

    }


}

const intent = () => ({
    keywords: [],
    module: 'createFile'
})

const examples = () => (
    []
)

module.exports = {
    get: document,
    hardRule,
    examples
}
