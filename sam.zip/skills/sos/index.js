function* send_sos(query) {


    let defaultSMS = "Hi MOM DAD Friends, I am Paramjit and my life is in danger, please help me, my phone no is 9051548195, and my address is 119,NSC Bose Road, Kolkata 700040, my dad's phone no is 9830039139, I am in Kolkata India right now";
    let defaultMessage = "Hi MOM DAD Friends, I am Paramjit and my life is in danger, please help me, my phone no is 9051548195, and my address is 119,NSC Bose Road, Kolkata 700040, my dad's phone no is 9830039139, I am in Kolkata India right now";
    let defaultTo = "+919051548195";
    let pintuNo = "+919051548195";


    if (query.includes('send sos')) {

        var twilio = require('twilio');

        var accountSid = 'ACd9b51d41966e35a88c9342f3c221ec04'; // Your Account SID from www.twilio.com/console
        var authToken = '94b48c12246e41df4dfc0544afe42806'; // Your Auth Token from www.twilio.com/console

        var twilio = require('twilio');
        var client = new twilio(accountSid, authToken);

        console.log("defaultTo: " + defaultTo + " defaultMessage: " + defaultMessage);
        client.messages.create({
                //body: 'Hello from SAM ',
                body: defaultMessage,
                //to: '+919051548195', // Text this number
                to: defaultTo, // Text this number	
                //from: '+12345678901' // From a valid Twilio number
                from: '+12012558285' // From a valid Twilio number	
            })
            .then((message) => console.log(message.sid));


        'use strict';
        const nodemailer = require('nodemailer');

        let transporter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'paramjit1992singh@gmail.com',
                pass: 'jasbinder'
            }
        });

        let mailOptions = {
            from: '"SAM 👻" <paramjit1992singh@gmail.com>', // sender address
            to: 'paramjit1992singh@gmail.com,bkmaan42@gmail.com', // list of receivers
            subject: 'SOS', // Subject line
            text: defaultMessage, // plain text body
            html: '<b>'+defaultMessage+'</b>' // html body
        };


        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
        });



    } else {


        return {
            text: 'Message Sent Failed! Please tell the correct phone number with ISD code followed by your message'
        }


    }


    return {

        text: 'Message Sent'
    }
}

const intent = () => ({
    keywords: ["sos"],
    module: 'sos'
})

const examples = () => (
    []
)

module.exports = {
    get: send_sos,
    intent,
    examples
}
