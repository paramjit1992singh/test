function* sms_resp(query) {


    let defaultSMS = "This is a default SMS from SAM";
    let defaultMessage = "Hello world!";
    let defaultTo = "+919051548195";
    let pintuNo = "+919051548195";	


    if (query.includes('send sms to') && (query.includes('subject') || query.includes('with subject') || query.includes('and subject') || query.includes('message') || query.includes('with message') || query.includes('and message'))) {

	if(query.includes('pintu')){
        
   	 defaultTo = pintuNo;

	}else{

        query = query.split('to')[1].trim();
        defaultTo = query;

	}


        if (query.includes('with subject')) {

            defaultTo = query.split('with subject')[0].trim();
            query = query.split('with subject')[1].trim();
            defaultMessage = query;

            if (defaultTo.includes('plus')) {

                defaultTo = "+" + defaultTo.substring(4);

            }


        } else if (query.includes('and subject')) {

            defaultTo = query.split('and subject')[0].trim();
            query = query.split('and subject')[1].trim();
            defaultMessage = query;

            if (defaultTo.includes('plus')) {

                defaultTo = "+" + defaultTo.substring(4);

            }


        } else if (query.includes('with message')) {

            defaultTo = query.split('with message')[0].trim();
            query = query.split('with message')[1].trim();
            defaultMessage = query;

            if (defaultTo.includes('plus')) {

                defaultTo = "+" + defaultTo.substring(4);

            }


        } else if (query.includes('and message')) {

            defaultTo = query.split('and message')[0].trim();
            query = query.split('and message')[1].trim();
            defaultMessage = query;

            if (defaultTo.includes('plus')) {

                defaultTo = "+" + defaultTo.substring(4);

            }


        } else if (query.includes('message')) {

            defaultTo = query.split('message')[0].trim();
            query = query.split('message')[1].trim();
            defaultMessage = query;

            if (defaultTo.includes('plus')) {

                defaultTo = "+" + defaultTo.substring(4);

            }


        } else if (query.includes('subject')) {

            defaultTo = query.split('subject')[0].trim();
            query = query.split('subject')[1].trim();
            defaultMessage = query;

            if (defaultTo.includes('plus')) {

                defaultTo = "+" + defaultTo.substring(4);

            }


        }


   var twilio = require('twilio');

    var accountSid = 'ACd9b51d41966e35a88c9342f3c221ec04'; // Your Account SID from www.twilio.com/console
    var authToken = '94b48c12246e41df4dfc0544afe42806'; // Your Auth Token from www.twilio.com/console

    var twilio = require('twilio');
    var client = new twilio(accountSid, authToken);

console.log("defaultTo: "+defaultTo+ " defaultMessage: "+defaultMessage);
    client.messages.create({
            //body: 'Hello from SAM ',
	    body: defaultMessage,
            //to: '+919051548195', // Text this number
	    to: defaultTo, // Text this number	
            //from: '+12345678901' // From a valid Twilio number
            from: '+12012558285' // From a valid Twilio number	
        })
        .then((message) => console.log(message.sid));






    } else {


        return {
            text: 'Message Sent Failed! Please tell the correct phone number with ISD code followed by your message'
        }


    }


  return {
   
     text: 'Message Sent'
    }
}

const intent = () => ({
    keywords: ["sms"],
    module: 'sms'
})

const examples = () => (
    []
)

module.exports = {
    get: sms_resp,
    intent,
    examples
}
