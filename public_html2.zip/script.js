function Graph(config) {
    // user defined properties
    this.canvas = document.getElementById(config.canvasId);
    this.minX = config.minX;
    this.minY = config.minY;
    this.maxX = config.maxX;
    this.maxY = config.maxY;
    this.unitsPerTick = config.unitsPerTick;

    // constants
    this.axisColor = '#aaa';
    this.font = '8pt Calibri';
    this.tickSize = 600;

    // relationships
    this.context = this.canvas.getContext('2d');
    this.rangeX = this.maxX - this.minX;
    this.rangeY = this.maxY - this.minY;
    this.unitX = this.canvas.width / this.rangeX;
    this.unitY = this.canvas.height / this.rangeY;
    this.centerY = Math.round(Math.abs(this.minY / this.rangeY) * this.canvas.height);
    this.centerX = Math.round(Math.abs(this.minX / this.rangeX) * this.canvas.width);
    this.iteration = (this.maxX - this.minX) / 1000;
    this.scaleX = this.canvas.width / this.rangeX;
    this.scaleY = this.canvas.height / this.rangeY;

    // draw x and y axis
    this.drawXAxis();
    this.drawYAxis();
}

Graph.prototype.drawXAxis = function () {
    var context = this.context;
    context.save();
    context.beginPath();
    context.moveTo(0, this.centerY);
    context.lineTo(this.canvas.width, this.centerY);
    context.strokeStyle = this.axisColor;
    context.lineWidth = 0.05;
    context.stroke();

    // draw tick marks
    var xPosIncrement = this.unitsPerTick * this.unitX;
    var xPos, unit;
    context.font = this.font;
    context.textAlign = 'center';
    context.textBaseline = 'top';

    // draw left tick marks
    xPos = this.centerX - xPosIncrement;
    unit = -1 * this.unitsPerTick;
    while (xPos > 0) {
        context.moveTo(xPos, this.centerY - this.tickSize / 2);
        context.lineTo(xPos, this.centerY + this.tickSize / 2);
        context.stroke();
        context.fillText(unit, xPos, this.centerY + 4);
        unit -= this.unitsPerTick;
        xPos = Math.round(xPos - xPosIncrement);
    }

    // draw right tick marks
    xPos = this.centerX + xPosIncrement;
    unit = this.unitsPerTick;
    while (xPos < this.canvas.width) {
        context.moveTo(xPos, this.centerY - this.tickSize / 2);
        context.lineTo(xPos, this.centerY + this.tickSize / 2);
        context.stroke();
        context.fillText(unit, xPos, this.centerY + 4);
        unit += this.unitsPerTick;
        xPos = Math.round(xPos + xPosIncrement);
    }

    context.fillText("X", xPos - 4, this.centerY + 4);
    context.restore();
};

Graph.prototype.drawYAxis = function () {
    var context = this.context;
    context.save();
    context.beginPath();
    context.moveTo(this.centerX, 0);
    context.lineTo(this.centerX, this.canvas.height);
    context.strokeStyle = this.axisColor;
    context.lineWidth = 0.05;
    context.stroke();

    // draw tick marks
    var yPosIncrement = this.unitsPerTick * this.unitY;
    var yPos, unit;
    context.font = this.font;
    context.textAlign = 'right';
    context.textBaseline = 'middle';

    // draw top tick marks
    yPos = this.centerY - yPosIncrement;
    unit = this.unitsPerTick;
    while (yPos > 0) {
        context.moveTo(this.centerX - this.tickSize / 2, yPos);
        context.lineTo(this.centerX + this.tickSize / 2, yPos);
        context.stroke();
        context.fillText(unit, this.centerX - 4, yPos);
        unit += this.unitsPerTick;
        yPos = Math.round(yPos - yPosIncrement);
    }

    context.fillText("Y", this.centerX - 4, yPos + 8);

    // draw bottom tick marks
    yPos = this.centerY + yPosIncrement;
    unit = -1 * this.unitsPerTick;
    while (yPos < this.canvas.height) {
        context.moveTo(this.centerX - this.tickSize / 2, yPos);
        context.lineTo(this.centerX + this.tickSize / 2, yPos);
        context.stroke();
        context.fillText(unit, this.centerX - 4, yPos);
        unit -= this.unitsPerTick;
        yPos = Math.round(yPos + yPosIncrement);
    }
    context.restore();
};

Graph.prototype.drawEquation = function (equation, color, thickness) {
    var context = this.context;
    context.save();
    context.save();
    this.transformContext();

    context.beginPath();
    context.moveTo(this.minX, equation(this.minX));

    for (var x = this.minX + this.iteration; x <= this.maxX; x += this.iteration) {
        context.lineTo(x, equation(x));
    }

    context.restore();
    context.lineJoin = 'round';
    context.lineWidth = thickness;
    context.strokeStyle = color;
    context.stroke();
    context.restore();
};

Graph.prototype.transformContext = function () {
    var context = this.context;

    // move context to center of canvas
    this.context.translate(this.centerX, this.centerY);

    /*
     * stretch grid to fit the canvas window, and
     * invert the y scale so that that increments
     * as you move upwards
     */
    context.scale(this.scaleX, -this.scaleY);
};


var myGraph = new Graph({
    canvasId: 'myCanvas',
    minX: -6,
    minY: -6,
    maxX: 6,
    maxY: 6,
    unitsPerTick: 1
});

var myGraph2 = new Graph({
    canvasId: 'myCanvas2',
    minX: -6,
    minY: -6,
    maxX: 6,
    maxY: 6,
    unitsPerTick: 1
});

//            myGraph.drawEquation(function (x) {
//                return 5 * Math.sin(x);
//            }, 'green', 3);
//
//            myGraph.drawEquation(function (x) {
//                return x * x;
//            }, 'blue', 3);

//myGraph.drawEquation(function (x) {
//    return 1 * x + 1;
//}, 'red', 3);
//
//myGraph.drawEquation(function (x) {
//    return 1 * x + 0;
//}, 'blue', 3);

function selectRandomNumber(min, max)
{
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function getMaxValue(min)
{
    min = parseInt(min, 10);

    if (min === -3) {
        return 2;
    } else if (min === -2) {
        return 3;
    } else if (min === -1 || min === 0) {
        return 4;
    } else {
        return 5;
    }

}

var canvas2 = document.getElementById('myCanvas');
var context = canvas2.getContext('2d');

angular.module('app', []);
angular.module('app').controller('init', ['$scope', function ($scope) {


        $scope.isVisible = true;


//y=ax+c

        myGraph2.drawEquation(function (x) {
            return (-1) * x + (2);
        }, 'red', 3);
        myGraph2.drawEquation(function (x) {
            return 1 * x + 0;
        }, 'blue', 3);

        //$scope.valueA = "1";
        //$scope.valueC = "0";





        $scope.newGame2 = function () {

            context.clearRect(0, 0, canvas2.width, canvas2.height);
            context.restore();
            var myGraph = new Graph({
                canvasId: 'myCanvas',
                minX: -6,
                minY: -6,
                maxX: 6,
                maxY: 6,
                unitsPerTick: 1
            });


            $scope.minA = selectRandomNumber(-3, 1);
            console.log("$scope.minA: " + $scope.minA);
            $scope.maxA = getMaxValue($scope.minA);
            console.log("$scope.maxA: " + (parseInt($scope.maxA, 10) - 1));
            $scope.minC = selectRandomNumber(-3, 1);
            console.log("$scope.minC: " + $scope.minC);
            $scope.maxC = getMaxValue($scope.minC);
            console.log("$scope.maxC: " + (parseInt($scope.maxC, 10) - 1));
            $scope.valueA = $scope.minA;
            $scope.valueC = $scope.minC;
            var redAValue = parseInt(selectRandomNumber(parseInt($scope.minA), (parseInt($scope.maxA, 10) - 1)));
            var redCValue = parseInt(selectRandomNumber(parseInt($scope.minC), (parseInt($scope.maxC, 10) - 1)));
            console.log("redAValue: " + redAValue);
            console.log("redCValue: " + redCValue);
//      var blueAValue = parseInt(selectRandomNumber(parseInt($scope.minA), (parseInt($scope.maxA, 10) - 1)));
//      var blueCValue = parseInt(selectRandomNumber(parseInt($scope.minC), (parseInt($scope.maxC, 10) - 1)));

            var blueAValue = parseInt($scope.valueA);
            var blueCValue = parseInt($scope.valueC);
            console.log("blueAValue: " + blueAValue);
            console.log("blueCValue: " + blueCValue);
            myGraph.drawEquation(function (x) {
                return (redAValue * x) + (redCValue);
            }, 'red', 3);
            myGraph.drawEquation(function (x) {
                return (blueAValue * x) + (blueCValue);
            }, 'blue', 3);


            $scope.changedValueA = function (item) {

                blueAValue = parseInt(item);
                context.clearRect(0, 0, canvas2.width, canvas2.height);
                context.restore();
                var myGraph = new Graph({
                    canvasId: 'myCanvas',
                    minX: -6,
                    minY: -6,
                    maxX: 6,
                    maxY: 6,
                    unitsPerTick: 1
                });
                myGraph.drawEquation(function (x) {
                    return (redAValue * x) + (redCValue);
                }, 'red', 3);
                myGraph.drawEquation(function (x) {
                    return (blueAValue * x) + (blueCValue);
                }, 'blue', 3);

                if ((blueAValue === redAValue) && (blueCValue === redCValue)) {
                    alert("done");
                }


            };
            $scope.changedValueC = function (item) {

                blueCValue = parseInt(item);
                context.clearRect(0, 0, canvas2.width, canvas2.height);
                context.restore();
                var myGraph = new Graph({
                    canvasId: 'myCanvas',
                    minX: -6,
                    minY: -6,
                    maxX: 6,
                    maxY: 6,
                    unitsPerTick: 1
                });
                myGraph.drawEquation(function (x) {
                    return (redAValue * x) + (redCValue);
                }, 'red', 3);
                myGraph.drawEquation(function (x) {
                    return (blueAValue * x) + (blueCValue);
                }, 'blue', 3);

                if ((blueAValue === redAValue) && (blueCValue === redCValue)) {
                    alert("done");
                }

            };

        };


    }]);

angular.module('app').filter('range', function () {
    return function (input, min, max) {
        min = parseInt(min, 10);
        max = parseInt(max, 10);
        for (var i = min; i < max; i++)
            input.push(i);
        return input;
    };
});

