function* emailSAM(query) {

    let defaultSubject = "This is a default message from SAM";
    let defaultMessage = "Hello world!";
    let defaultTo = "paramjit1992singh@gmail.com";
    let defaultAttachment = "";


    if (query.includes('send email to') || (query.includes('subject') || query.includes('with subject')) && (query.includes('message') || query.includes('with message') || query.includes('and message')) || (query.includes('attachment') || query.includes('with attachment') || query.includes('and attachment'))) {

        query = query.split('to')[1].trim();
        defaultTo = query;


        if (query.includes('with subject')) {

            defaultTo = query.split('with subject')[0].trim();
            query = query.split('with subject')[1].trim();
            defaultSubject = query;

            if (query.includes('with message')) {

                defaultSubject = query.split('with message')[0].trim();
                query = query.split('with message')[1].trim();
                defaultMessage = query;

                if (query.includes('with attachment')) {
                    defaultMessage = query.split('with attachment')[0].trim();
                    query = query.split('with attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('and attachment')) {
                    defaultMessage = query.split('and attachment')[0].trim();
                    query = query.split('and attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('attachment')) {
                    defaultMessage = query.split('attachment')[0].trim();
                    query = query.split('attachment')[1].trim();
                    defaultAttachment = query;

                }



            } else if (query.includes('and message')) {

                defaultSubject = query.split('and message')[0].trim();
                query = query.split('and message')[1].trim();
                defaultMessage = query;

                if (query.includes('with attachment')) {
                    defaultMessage = query.split('with attachment')[0].trim();
                    query = query.split('with attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('and attachment')) {
                    defaultMessage = query.split('and attachment')[0].trim();
                    query = query.split('and attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('attachment')) {
                    defaultMessage = query.split('attachment')[0].trim();
                    query = query.split('attachment')[1].trim();
                    defaultAttachment = query;

                }

            } else if (query.includes('message')) {

                defaultSubject = query.split('message')[0].trim();
                query = query.split('message')[1].trim();
                defaultMessage = query;

                if (query.includes('with attachment')) {
                    defaultMessage = query.split('with attachment')[0].trim();
                    query = query.split('with attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('and attachment')) {
                    defaultMessage = query.split('and attachment')[0].trim();
                    query = query.split('and attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('attachment')) {
                    defaultMessage = query.split('attachment')[0].trim();
                    query = query.split('attachment')[1].trim();
                    defaultAttachment = query;

                }


            }

        } else if (query.includes('subject')) {

            defaultTo = query.split('subject')[0].trim();
            query = query.split('subject')[1].trim();
            defaultSubject = query;

            if (query.includes('with message')) {

                defaultSubject = query.split('with message')[0].trim();
                query = query.split('with message')[1].trim();
                defaultMessage = query;

                if (query.includes('with attachment')) {
                    defaultMessage = query.split('with attachment')[0].trim();
                    query = query.split('with attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('and attachment')) {
                    defaultMessage = query.split('and attachment')[0].trim();
                    query = query.split('and attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('attachment')) {
                    defaultMessage = query.split('attachment')[0].trim();
                    query = query.split('attachment')[1].trim();
                    defaultAttachment = query;

                }



            } else if (query.includes('and message')) {

                defaultSubject = query.split('and message')[0].trim();
                query = query.split('and message')[1].trim();
                defaultMessage = query;

                if (query.includes('with attachment')) {
                    defaultMessage = query.split('with attachment')[0].trim();
                    query = query.split('with attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('and attachment')) {
                    defaultMessage = query.split('and attachment')[0].trim();
                    query = query.split('and attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('attachment')) {
                    defaultMessage = query.split('attachment')[0].trim();
                    query = query.split('attachment')[1].trim();
                    defaultAttachment = query;

                }

            } else if (query.includes('message')) {

                defaultSubject = query.split('message')[0].trim();
                query = query.split('message')[1].trim();
                defaultMessage = query;

                if (query.includes('with attachment')) {
                    defaultMessage = query.split('with attachment')[0].trim();
                    query = query.split('with attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('and attachment')) {
                    defaultMessage = query.split('and attachment')[0].trim();
                    query = query.split('and attachment')[1].trim();
                    defaultAttachment = query;

                } else if (query.includes('attachment')) {
                    defaultMessage = query.split('attachment')[0].trim();
                    query = query.split('attachment')[1].trim();
                    defaultAttachment = query;

                }


            }


        }


        if (defaultTo.substr(defaultTo.length - 3) == "com") {

            let com = defaultTo.substr(defaultTo.length - 3);
            console.log("com: " + com);
            if (com == "com") {
                defaultTo = defaultTo.slice(0, -3) + "." + com;

            }

        } else if (defaultTo.substr(defaultTo.length - 4) == "coin") {

            let coin = defaultTo.substr(defaultTo.length - 4);
            console.log("coin: " + coin);
            if (coin == "coin") {
                defaultTo = defaultTo.slice(0, -4) + ".co.in";

            }

        }



        console.log("defaultSubject: " + defaultSubject);
        console.log("defaultMessage: " + defaultMessage);
        console.log("defaultTo: " + defaultTo);
        console.log("defaultAttachment: " + defaultAttachment);


        'use strict';
        const nodemailer = require('nodemailer');

        let transporter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'paramjit1992singh@gmail.com',
                pass: 'jasbinder'
            }
        });

        let mailOptions = {
            from: '"SAM 👻" <paramjit1992singh@gmail.com>', // sender address
            to: 'paramjit1992singh@gmail.com', // list of receivers
            subject: 'Hello ✔', // Subject line
            text: 'Hello world ?', // plain text body
            html: '<b>Hello world ?</b>' // html body
        };


        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
        });

        return {
            text: 'Your message has been sent successfully'
        }

    }

}

const intent = () => ({
    keywords: ["email"],
    module: 'email'
})

const examples = () => (
    []
)

module.exports = {
    get: emailSAM,
    intent,
    examples
}
