function hardRule(query, breakdown) {
    return query.startsWith('describe yourself') || query.startsWith('who are you') ||
            query.startsWith('what is your name') ||query.startsWith('whats your name') || query.startsWith('what is sam') || query.startsWith('what are you called') || query.startsWith('who made you') || query.startsWith('who created you') || query.startsWith('you are created by') || query.startsWith('you are developed by') || query.startsWith('what can you do') || query.startsWith('what are your features') || query.startsWith('tell me about your self') || query.startsWith('your name') || query.startsWith('you are called') || query.startsWith('how are you created') || query.startsWith('you are developed using') || query.startsWith('what is your technology stack') || query.startsWith('whats your technology stack') || query.startsWith('tell me your technology stack') || query.startsWith('tell your technology stack')
}

function * describe_yourself(query, breakdown, user) {
    if (query.startsWith('describe yourself') || query.startsWith('who are you') ||
            query.startsWith('what is your name') ||query.startsWith('whats your name') || query.startsWith('what is sam') || query.startsWith('what are you called') || query.startsWith('who made you')|| query.startsWith('your name') || query.startsWith('you are called')) {

        return {text: 'I Am SAM! , An Intelligent Personal Assistant, Designed And Developed By Paramjit'}
    
} else if (query.startsWith('who created you') || query.startsWith('you are created by')) {

        return {text: 'I\'m created by Paramjit'}

    } else if (query.startsWith('what can you do') || query.startsWith('what are your features')) {

        return {text: 'I have the ability to access information from a variety of online sources such as weather conditions, traffic congestion, news etc'}

    } else if (query.startsWith('tell me about your self')) {

        return {text: 'I Am SAM! , An Intelligent Personal Assistant, Designed And Developed By Paramjit. I have the ability to access information from a variety of online sources such as weather conditions, traffic congestion, news etc'}

    } else if (query.startsWith('who created you') || query.startsWith('you are created by') || query.startsWith('you are developed by') ) {

        return {text: 'I\'m created by Paramjit'}

    } else if (query.startsWith('how are you created') || query.startsWith('you are developed using') || query.startsWith('what is your technology stack') || query.startsWith('whats your technology stack') || query.startsWith('tell me your technology stack') || query.startsWith('tell your technology stack')) {

        return {text: 'I\'m developed using Node.Js, Html, Jquery, Natural Language Processing, Artificial Intelligence Markup Language'}

    } else {

        return {text: 'I\'m sorry, I did\'t quite understand you...'}

    }
}

const examples = () => (
    ['describe yourself',"who are you"]
)

module.exports = {
    get: describe_yourself,
    hardRule,
    examples
}
