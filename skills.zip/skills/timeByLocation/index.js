function hardRule(query, breakdown) {
    return query.startsWith('what time is it in') || query.startsWith('what is the time in') || query.startsWith('time in') || query.startsWith('get the time in') || query.startsWith('get me the time in') || query.startsWith('get the time at') || query.includes('what is the time now in') || query.startsWith('time now in') || query.startsWith('get the time now in') || query.startsWith('get me the time now in') || query.startsWith('get the time now at') || query.startsWith('What\'s the current time in') || query.startsWith('What\'s the current time at')
}


const intent = () => ({
    keywords: [],
    module: 'timeByLocation'
})

function worldClock(zone, region) {
    var dst = 0
    var time = new Date()
    var gmtMS = time.getTime() + (time.getTimezoneOffset() * 60000)
    var gmtTime = new Date(gmtMS)
    var day = gmtTime.getDate()
    var month = gmtTime.getMonth()
    var year = gmtTime.getYear()
    if (year < 1000) {
        year += 1900
    }
    var monthArray = new Array("January", "February", "March", "April", "May", "June", "July", "August",
        "September", "October", "November", "December")
    var monthDays = new Array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
    if (year % 4 == 0) {
        monthDays = new Array("31", "29", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
    }
    if (year % 100 == 0 && year % 400 != 0) {
        monthDays = new Array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
    }

    var hr = gmtTime.getHours() + zone
    var min = gmtTime.getMinutes()
    var sec = gmtTime.getSeconds()

    if (hr >= 24) {
        hr = hr - 24
        day -= -1
    }
    if (hr < 0) {
        hr -= -24
        day -= 1
    }
    if (hr < 10) {
        hr = " " + hr
    }
    if (min < 10) {
        min = "0" + min
    }
    if (sec < 10) {
        sec = "0" + sec
    }
    if (day <= 0) {
        if (month == 0) {
            month = 11
            year -= 1
        } else {
            month = month - 1
        }
        day = monthDays[month]
    }
    if (day > monthDays[month]) {
        day = 1
        if (month == 11) {
            month = 0
            year -= -1
        } else {
            month -= -1
        }
    }
    if (region == "NAmerica") {
        var startDST = new Date()
        var endDST = new Date()
        startDST.setMonth(3)
        startDST.setHours(2)
        startDST.setDate(1)
        var dayDST = startDST.getDay()
        if (dayDST != 0) {
            startDST.setDate(8 - dayDST)
        } else {
            startDST.setDate(1)
        }
        endDST.setMonth(9)
        endDST.setHours(1)
        endDST.setDate(31)
        dayDST = endDST.getDay()
        endDST.setDate(31 - dayDST)
        var currentTime = new Date()
        currentTime.setMonth(month)
        currentTime.setYear(year)
        currentTime.setDate(day)
        currentTime.setHours(hr)
        if (currentTime >= startDST && currentTime < endDST) {
            dst = 1
        }
    }
    if (region == "Europe") {
        var startDST = new Date()
        var endDST = new Date()
        startDST.setMonth(2)
        startDST.setHours(1)
        startDST.setDate(31)
        var dayDST = startDST.getDay()
        startDST.setDate(31 - dayDST)
        endDST.setMonth(9)
        endDST.setHours(0)
        endDST.setDate(31)
        dayDST = endDST.getDay()
        endDST.setDate(31 - dayDST)
        var currentTime = new Date()
        currentTime.setMonth(month)
        currentTime.setYear(year)
        currentTime.setDate(day)
        currentTime.setHours(hr)
        if (currentTime >= startDST && currentTime < endDST) {
            dst = 1
        }
    }

    if (region == "SAmerica") {
        var startDST = new Date()
        var endDST = new Date()
        startDST.setMonth(9)
        startDST.setHours(0)
        startDST.setDate(1)
        var dayDST = startDST.getDay()
        if (dayDST != 0) {
            startDST.setDate(22 - dayDST)
        } else {
            startDST.setDate(15)
        }
        endDST.setMonth(1)
        endDST.setHours(11)
        endDST.setDate(1)
        dayDST = endDST.getDay()
        if (dayDST != 0) {
            endDST.setDate(21 - dayDST)
        } else {
            endDST.setDate(14)
        }
        var currentTime = new Date()
        currentTime.setMonth(month)
        currentTime.setYear(year)
        currentTime.setDate(day)
        currentTime.setHours(hr)
        if (currentTime >= startDST || currentTime < endDST) {
            dst = 1
        }
    }
    if (region == "Cairo") {
        var startDST = new Date()
        var endDST = new Date()
        startDST.setMonth(3)
        startDST.setHours(0)
        startDST.setDate(30)
        var dayDST = startDST.getDay()
        if (dayDST < 5) {
            startDST.setDate(28 - dayDST)
        } else {
            startDST.setDate(35 - dayDST)
        }
        endDST.setMonth(8)
        endDST.setHours(11)
        endDST.setDate(30)
        dayDST = endDST.getDay()
        if (dayDST < 4) {
            endDST.setDate(27 - dayDST)
        } else {
            endDST.setDate(34 - dayDST)
        }
        var currentTime = new Date()
        currentTime.setMonth(month)
        currentTime.setYear(year)
        currentTime.setDate(day)
        currentTime.setHours(hr)
        if (currentTime >= startDST && currentTime < endDST) {
            dst = 1
        }
    }
    if (region == "Israel") {
        var startDST = new Date()
        var endDST = new Date()
        startDST.setMonth(3)
        startDST.setHours(2)
        startDST.setDate(1)
        endDST.setMonth(8)
        endDST.setHours(2)
        endDST.setDate(25)
        dayDST = endDST.getDay()
        if (dayDST != 0) {
            endDST.setDate(32 - dayDST)
        } else {
            endDST.setDate(1)
            endDST.setMonth(9)
        }
        var currentTime = new Date()
        currentTime.setMonth(month)
        currentTime.setYear(year)
        currentTime.setDate(day)
        currentTime.setHours(hr)
        if (currentTime >= startDST && currentTime < endDST) {
            dst = 1
        }
    }
    if (region == "Beirut") {
        var startDST = new Date()
        var endDST = new Date()
        startDST.setMonth(2)
        startDST.setHours(0)
        startDST.setDate(31)
        var dayDST = startDST.getDay()
        startDST.setDate(31 - dayDST)
        endDST.setMonth(9)
        endDST.setHours(11)
        endDST.setDate(31)
        dayDST = endDST.getDay()
        endDST.setDate(30 - dayDST)
        var currentTime = new Date()
        currentTime.setMonth(month)
        currentTime.setYear(year)
        currentTime.setDate(day)
        currentTime.setHours(hr)
        if (currentTime >= startDST && currentTime < endDST) {
            dst = 1
        }
    }
    if (region == "Baghdad") {
        var startDST = new Date()
        var endDST = new Date()
        startDST.setMonth(3)
        startDST.setHours(3)
        startDST.setDate(1)
        endDST.setMonth(9)
        endDST.setHours(3)
        endDST.setDate(1)
        dayDST = endDST.getDay()
        var currentTime = new Date()
        currentTime.setMonth(month)
        currentTime.setYear(year)
        currentTime.setDate(day)
        currentTime.setHours(hr)
        if (currentTime >= startDST && currentTime < endDST) {
            dst = 1
        }
    }
    if (region == "Australia") {
        var startDST = new Date()
        var endDST = new Date()
        startDST.setMonth(9)
        startDST.setHours(2)
        startDST.setDate(31)
        var dayDST = startDST.getDay()
        startDST.setDate(31 - dayDST)
        endDST.setMonth(2)
        endDST.setHours(2)
        endDST.setDate(31)
        dayDST = endDST.getDay()
        endDST.setDate(31 - dayDST)
        var currentTime = new Date()
        currentTime.setMonth(month)
        currentTime.setYear(year)
        currentTime.setDate(day)
        currentTime.setHours(hr)
        if (currentTime >= startDST || currentTime < endDST) {
            dst = 1
        }
    }


    if (dst == 1) {
        hr -= -1
        if (hr >= 24) {
            hr = hr - 24
            day -= -1
        }
        if (hr < 10) {
            hr = " " + hr
        }
        if (day > monthDays[month]) {
            day = 1
            if (month == 11) {
                month = 0
                year -= -1
            } else {
                month -= -1
            }
        }
        return monthArray[month] + " " + day + ", " + year + "<br>" + hr + ":" + min + ":" + sec + " DST"
    } else {
        return monthArray[month] + " " + day + ", " + year + "<br>" + hr + ":" + min + ":" + sec
    }
}


function* time_Location(query) {

    let defaultLocation = "";
    let locationArray = ["GMT", "Vancouver", "SanFrancisco", "Seattle", "LosAngeles", "Denver", "MexicoCity", "Houston", "Minneapolis", "NewOrleans", "Chicago", "Montgomery", "Indianapolis", "Atlanta", "Detroit", "Miami", "WashingtonDC", "Philadelphia", "NewYork", "Montreal", "Boston", "BuenosAires", "SaoPaulo", "RioDeJaneiro", "Lisbon", "Dublin", "London", "Madrid", "Barcelona", "Paris", "Brussels", "Amsterdam", "Frankfurt", "Rome", "Berlin", "Prague", "Vienna", "Stockholm", "Athens", "Helsinki", "Minsk", "Istanbul", "Cairo", "Jerusalem", "Beirut", "Moscow", "Baghdad", "Dubai", "Bangkok", "Jakarta", "HongKong", "Beijing", "Shanghai", "Seoul", "Tokyo", "Melbourne", "Sydney", "Brisbane", "Vladivostok", "Kamchatka"];

    let locationArrayToUp = String.prototype.toUpperCase.apply(locationArray).split(",");
    let timezoneIndexArray = [0, -8, -8, -8, -8, -7, -6, -6, -6, -6, -6, -6, -5, -5, -5, -5, -5, -5, -5, -5, -5, -3, -3, -3, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 4, 7, 7, 8, 8, 8, 9, 9, 10, 10, 10, 10, 12];
    let countryContinentLocation = ["Greenwich", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "NAmerica", "BuenosAires", "SAmerica", "SAmerica", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Europe", "Cairo", "Israel", "Beirut", "Europe", "Baghdad", "Dubai", "Bangkok", "Jakarta", "HongKong", "Beijing", "Shanghai", "Seoul", "Tokyo", "Australia", "Australia", "Brisbane", "Europe", "Europe"];

    if (query.includes('what time is it in') || query.includes('what is the time in') || query.includes('time in') || query.includes('get the time in') || query.includes('get me the time in') || query.includes('what is the time now in') || query.includes('time now in') || query.includes('get the time now in') || query.includes('get me the time now in') || query.startsWith('What\'s the current time in')) {

        location = query.split('in')[1].trim();
	defaultLocation=location;

    } else if (query.includes('what time is it at') || query.includes('what is the time at') || query.includes('time at') || query.includes('get the time at') || query.includes('get me the time at') || query.includes('what is the time now at') || query.includes('time now at') || query.includes('get the time now at') || query.includes('get me the time now at') || query.includes('get the time at') || query.startsWith('What\'s the current time at')) {

        location = query.split('at')[1].trim();
	defaultLocation=location;
    }


    console.log("location: " + location);
    let indexLocation = locationArrayToUp.indexOf(location.toUpperCase());

    if (indexLocation != -1) {
        let countryContinentLocationValue = countryContinentLocation[indexLocation];
        let locationTimeZoneIndex = timezoneIndexArray[indexLocation];

        return {
            text: 'It is ' + worldClock(locationTimeZoneIndex, countryContinentLocationValue) + " in " + defaultLocation.charAt(0).toUpperCase() + defaultLocation.slice(1)
        }


    } else {

        const time = new Date().toLocaleTimeString('en-GB', {
            hour: 'numeric',
            minute: 'numeric'
        })


        return {
            text: "This feature is under development, how ever time in Kolkata, India is " + time
        }


    }


}

const examples = () => (
    []
)

module.exports = {
    get: time_Location,
    hardRule
}
