function hardRule(query, breakdown) {
    return query.startsWith('show all files in the directory') || query.startsWith('show me all files in the directory') || query.startsWith('read all files in the directory') || query.startsWith('read me all files in the directory') || query.startsWith('list all files in the directory') || query.startsWith('list me all files in the directory') || query.startsWith('read me all files in the directory') || query.startsWith('show all files') || query.startsWith('show me all files') || query.startsWith('read all files') || query.startsWith('read me all files') || query.startsWith('list all files') || query.startsWith('list me all files') || query.startsWith('read me all files') || query.startsWith('show all my files in the directory') || query.startsWith('show me all my files in the directory') || query.startsWith('read all my files in the directory') || query.startsWith('read me all my files in the directory') || query.startsWith('list all my files in the directory') || query.startsWith('list me all my files in the directory') || query.startsWith('read me all my files in the directory') || query.startsWith('show all my files') || query.startsWith('show me all my files') || query.startsWith('read all my files') || query.startsWith('read me all my files') || query.startsWith('list all my files') || query.startsWith('list me all my files') || query.startsWith('show all the files in the directory') || query.startsWith('show me all the files in the directory') || query.startsWith('read all the files in the directory') || query.startsWith('read me all the files in the directory') || query.startsWith('list all the files in the directory') || query.startsWith('list me all the files in the directory') || query.startsWith('read me all the files in the directory') || query.startsWith('show all the files') || query.startsWith('show me all the files') || query.startsWith('read all the files') || query.startsWith('read me all the files') || query.startsWith('list all the files') || query.startsWith('list me all the files') || query.startsWith('list files')
}


function* list_File() {

    if (query.startsWith('show all files in the directory') || query.startsWith('show me all files in the directory') || query.startsWith('read all files in the directory') || query.startsWith('read me all files in the directory') || query.startsWith('list all files in the directory') || query.startsWith('list me all files in the directory') || query.startsWith('read me all files in the directory') || query.startsWith('show all files') || query.startsWith('show me all files') || query.startsWith('read all files') || query.startsWith('read me all files') || query.startsWith('list all files') || query.startsWith('list me all files') || query.startsWith('read me all files') || query.startsWith('show all my files in the directory') || query.startsWith('show me all my files in the directory') || query.startsWith('read all my files in the directory') || query.startsWith('read me all my files in the directory') || query.startsWith('list all my files in the directory') || query.startsWith('list me all my files in the directory') || query.startsWith('read me all my files in the directory') || query.startsWith('show all my files') || query.startsWith('show me all my files') || query.startsWith('read all my files') || query.startsWith('read me all my files') || query.startsWith('list all my files') || query.startsWith('list me all my files') || query.startsWith('show all the files in the directory') || query.startsWith('show me all the files in the directory') || query.startsWith('read all the files in the directory') || query.startsWith('read me all the files in the directory') || query.startsWith('list all the files in the directory') || query.startsWith('list me all the files in the directory') || query.startsWith('read me all the files in the directory') || query.startsWith('show all the files') || query.startsWith('show me all the files') || query.startsWith('read all the files') || query.startsWith('read me all the files') || query.startsWith('list all the files') || query.startsWith('list me all the files') || query.startsWith('list files')) {

        let fs = require('fs');
        let fileName = "new_text_file_createdby_sam";
        let content = "abc";
        let directoryName = "./file_directory_created_by_sam";
        let files = [];



        var walk = require('walk');
        let f = "";

        if (query.includes('all files') || query.includes('all the files') || query.includes('all my files') || query.includes('list files')) {


            // Walker options
            var walker = walk.walk(directoryName, {
                followLinks: false
            });

            walker.on('file', function(root, stat, next) {
                // Add this file to the list of files
                files.push(stat.name);
                //files.push(root + '/' + stat.name);
                next();
            });

            walker.on('end', function() {
                //console.log(files.join());
                f = files.toString(', ');

            });

            return {
                text: "Sir! These are all the files present in this directory " + directoryName + " : " + f

            }



        } else {
            return {
                text: "Sir! There are no files in this directory " + directoryName
            }

        }
    } else {
        return {
            text: "This feature is under development"
        }

    }

    //return {text: 'Hello World'}
}

const intent = () => ({
    keywords: [],
    module: 'listFile'
})

const examples = () => (
    []
)

module.exports = {
    get: list_File,
    hardRule,
    examples
}
