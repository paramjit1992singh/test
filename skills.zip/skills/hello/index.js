function * hello_resp() {
    return {text: 'Hello Sir, I\'m Sam at your service! '}
}

const intent = () => ({
    keywords: ["hello","hii","hi"], module: 'hello'
})

const examples = () => (
    []
)

module.exports = {
    get: hello_resp,
    intent,
    examples
}
