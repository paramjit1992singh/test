function hardRule(query, breakdown) {
    return query.startsWith('what is the population of') || query.startsWith('what is the population of') || query.startsWith('what is the population for') || query.startsWith('what is the population for') || query.startsWith('what is the population of') || query.startsWith('what is the population of') || query.startsWith('what is the population for') || query.startsWith('what is the population for') || query.startsWith('what is the population of') || query.startsWith('what is the population of') || query.startsWith('what is the population for') || query.startsWith('what is the population for') || query.startsWith('tell me the population of') || query.startsWith('tell me the population of') || query.startsWith('tell me the population for') || query.startsWith('tell me the population for') || query.startsWith('tell me the population of') || query.startsWith('tell me the population of') || query.startsWith('tell me the population for') || query.startsWith('tell me the population for') || query.startsWith('tell me the population of') || query.startsWith('tell me the population of') || query.startsWith('tell me the population for') || query.startsWith('tell me the population for') || query.startsWith('What\'s the population of') || query.startsWith('What\'s the population of') || query.startsWith('What\'s the population for') || query.startsWith('What\'s the population for') || query.startsWith('What\'s the population of') || query.startsWith('What\'s the population of') || query.startsWith('What\'s the population for') || query.startsWith('What\'s the population for') || query.startsWith('What\'s the population of') || query.startsWith('What\'s the population of') || query.startsWith('What\'s the population for') || query.startsWith('What\'s the population for') || query.startsWith('get the population of') || query.startsWith('get the population of') || query.startsWith('get the population for') || query.startsWith('get the population for') || query.startsWith('get the population of') || query.startsWith('get the population of') || query.startsWith('get the population for') || query.startsWith('get the population for') || query.startsWith('get the population of') || query.startsWith('get the population of') || query.startsWith('get the population for') || query.startsWith('get the population for') || query.startsWith('get me the population of') || query.startsWith('get me the population of') || query.startsWith('get me the population for') || query.startsWith('get me the population for') || query.startsWith('get me the population of') || query.startsWith('get me the population of') || query.startsWith('get me the population for') || query.startsWith('get me the population for') || query.startsWith('get me the population of') || query.startsWith('get me the population of') || query.startsWith('get me the population for') || query.startsWith('get me the population for') || query.startsWith('tell the population of') || query.startsWith('tell the population of') || query.startsWith('tell the population for') || query.startsWith('tell the population for') || query.startsWith('tell the population of') || query.startsWith('tell the population of') || query.startsWith('tell the population for') || query.startsWith('tell the population for') || query.startsWith('tell the population of') || query.startsWith('tell the population of') || query.startsWith('tell the population for') || query.startsWith('tell the population for') || query.startsWith('population for') || query.startsWith('population for') || query.startsWith('population of') || query.startsWith('population of') || query.startsWith('what is the area of') || query.startsWith('what is the area of') || query.startsWith('what is the area for') || query.startsWith('what is the area for') || query.startsWith('what is the area of') || query.startsWith('what is the area of') || query.startsWith('what is the area for') || query.startsWith('what is the area for') || query.startsWith('what is the area of') || query.startsWith('what is the area of') || query.startsWith('what is the area for') || query.startsWith('what is the area for') || query.startsWith('tell me the area of') || query.startsWith('tell me the area of') || query.startsWith('tell me the area for') || query.startsWith('tell me the area for') || query.startsWith('tell me the area of') || query.startsWith('tell me the area of') || query.startsWith('tell me the area for') || query.startsWith('tell me the area for') || query.startsWith('tell me the area of') || query.startsWith('tell me the area of') || query.startsWith('tell me the area for') || query.startsWith('tell me the area for') || query.startsWith('What\'s the area of') || query.startsWith('What\'s the area of') || query.startsWith('What\'s the area for') || query.startsWith('What\'s the area for') || query.startsWith('What\'s the area of') || query.startsWith('What\'s the area of') || query.startsWith('What\'s the area for') || query.startsWith('What\'s the area for') || query.startsWith('What\'s the area of') || query.startsWith('What\'s the area of') || query.startsWith('What\'s the area for') || query.startsWith('What\'s the area for') || query.startsWith('get the area of') || query.startsWith('get the area of') || query.startsWith('get the area for') || query.startsWith('get the area for') || query.startsWith('get the area of') || query.startsWith('get the area of') || query.startsWith('get the area for') || query.startsWith('get the area for') || query.startsWith('get the area of') || query.startsWith('get the area of') || query.startsWith('get the area for') || query.startsWith('get the area for') || query.startsWith('get me the area of') || query.startsWith('get me the area of') || query.startsWith('get me the area for') || query.startsWith('get me the area for') || query.startsWith('get me the area of') || query.startsWith('get me the area of') || query.startsWith('get me the area for') || query.startsWith('get me the area for') || query.startsWith('get me the area of') || query.startsWith('get me the area of') || query.startsWith('get me the area for') || query.startsWith('get me the area for') || query.startsWith('tell the area of') || query.startsWith('tell the area of') || query.startsWith('tell the area for') || query.startsWith('tell the area for') || query.startsWith('tell the area of') || query.startsWith('tell the area of') || query.startsWith('tell the area for') || query.startsWith('tell the area for') || query.startsWith('tell the area of') || query.startsWith('tell the area of') || query.startsWith('tell the area for') || query.startsWith('tell the area for') || query.startsWith('area for') || query.startsWith('area for') || query.startsWith('area of') || query.startsWith('area of') || query.startsWith('what is the subregion of') || query.startsWith('what is the subregion of') || query.startsWith('what is the subregion for') || query.startsWith('what is the subregion for') || query.startsWith('what is the subregion of') || query.startsWith('what is the subregion of') || query.startsWith('what is the subregion for') || query.startsWith('what is the subregion for') || query.startsWith('what is the subregion of') || query.startsWith('what is the subregion of') || query.startsWith('what is the subregion for') || query.startsWith('what is the subregion for') || query.startsWith('tell me the subregion of') || query.startsWith('tell me the subregion of') || query.startsWith('tell me the subregion for') || query.startsWith('tell me the subregion for') || query.startsWith('tell me the subregion of') || query.startsWith('tell me the subregion of') || query.startsWith('tell me the subregion for') || query.startsWith('tell me the subregion for') || query.startsWith('tell me the subregion of') || query.startsWith('tell me the subregion of') || query.startsWith('tell me the subregion for') || query.startsWith('tell me the subregion for') || query.startsWith('What\'s the subregion of') || query.startsWith('What\'s the subregion of') || query.startsWith('What\'s the subregion for') || query.startsWith('What\'s the subregion for') || query.startsWith('What\'s the subregion of') || query.startsWith('What\'s the subregion of') || query.startsWith('What\'s the subregion for') || query.startsWith('What\'s the subregion for') || query.startsWith('What\'s the subregion of') || query.startsWith('What\'s the subregion of') || query.startsWith('What\'s the subregion for') || query.startsWith('What\'s the subregion for') || query.startsWith('get the subregion of') || query.startsWith('get the subregion of') || query.startsWith('get the subregion for') || query.startsWith('get the subregion for') || query.startsWith('get the subregion of') || query.startsWith('get the subregion of') || query.startsWith('get the subregion for') || query.startsWith('get the subregion for') || query.startsWith('get the subregion of') || query.startsWith('get the subregion of') || query.startsWith('get the subregion for') || query.startsWith('get the subregion for') || query.startsWith('get me the subregion of') || query.startsWith('get me the subregion of') || query.startsWith('get me the subregion for') || query.startsWith('get me the subregion for') || query.startsWith('get me the subregion of') || query.startsWith('get me the subregion of') || query.startsWith('get me the subregion for') || query.startsWith('get me the subregion for') || query.startsWith('get me the subregion of') || query.startsWith('get me the subregion of') || query.startsWith('get me the subregion for') || query.startsWith('get me the subregion for') || query.startsWith('tell the subregion of') || query.startsWith('tell the subregion of') || query.startsWith('tell the subregion for') || query.startsWith('tell the subregion for') || query.startsWith('tell the subregion of') || query.startsWith('tell the subregion of') || query.startsWith('tell the subregion for') || query.startsWith('tell the subregion for') || query.startsWith('tell the subregion of') || query.startsWith('tell the subregion of') || query.startsWith('tell the subregion for') || query.startsWith('tell the subregion for') || query.startsWith('subregion for') || query.startsWith('subregion for') || query.startsWith('subregion of') || query.startsWith('subregion of') || query.startsWith('what is the continent of') || query.startsWith('what is the continent of') || query.startsWith('what is the continent for') || query.startsWith('what is the continent for') || query.startsWith('what is the continent of') || query.startsWith('what is the continent of') || query.startsWith('what is the continent for') || query.startsWith('what is the continent for') || query.startsWith('what is the continent of') || query.startsWith('what is the continent of') || query.startsWith('what is the continent for') || query.startsWith('what is the continent for') || query.startsWith('tell me the continent of') || query.startsWith('tell me the continent of') || query.startsWith('tell me the continent for') || query.startsWith('tell me the continent for') || query.startsWith('tell me the continent of') || query.startsWith('tell me the continent of') || query.startsWith('tell me the continent for') || query.startsWith('tell me the continent for') || query.startsWith('tell me the continent of') || query.startsWith('tell me the continent of') || query.startsWith('tell me the continent for') || query.startsWith('tell me the continent for') || query.startsWith('What\'s the continent of') || query.startsWith('What\'s the continent of') || query.startsWith('What\'s the continent for') || query.startsWith('What\'s the continent for') || query.startsWith('What\'s the continent of') || query.startsWith('What\'s the continent of') || query.startsWith('What\'s the continent for') || query.startsWith('What\'s the continent for') || query.startsWith('What\'s the continent of') || query.startsWith('What\'s the continent of') || query.startsWith('What\'s the continent for') || query.startsWith('What\'s the continent for') || query.startsWith('get the continent of') || query.startsWith('get the continent of') || query.startsWith('get the continent for') || query.startsWith('get the continent for') || query.startsWith('get the continent of') || query.startsWith('get the continent of') || query.startsWith('get the continent for') || query.startsWith('get the continent for') || query.startsWith('get the continent of') || query.startsWith('get the continent of') || query.startsWith('get the continent for') || query.startsWith('get the continent for') || query.startsWith('get me the continent of') || query.startsWith('get me the continent of') || query.startsWith('get me the continent for') || query.startsWith('get me the continent for') || query.startsWith('get me the continent of') || query.startsWith('get me the continent of') || query.startsWith('get me the continent for') || query.startsWith('get me the continent for') || query.startsWith('get me the continent of') || query.startsWith('get me the continent of') || query.startsWith('get me the continent for') || query.startsWith('get me the continent for') || query.startsWith('tell the continent of') || query.startsWith('tell the continent of') || query.startsWith('tell the continent for') || query.startsWith('tell the continent for') || query.startsWith('tell the continent of') || query.startsWith('tell the continent of') || query.startsWith('tell the continent for') || query.startsWith('tell the continent for') || query.startsWith('tell the continent of') || query.startsWith('tell the continent of') || query.startsWith('tell the continent for') || query.startsWith('tell the continent for') || query.startsWith('continent for') || query.startsWith('continent for') || query.startsWith('continent of') || query.startsWith('continent of') || query.startsWith('to which continent')
}


const request = require('co-request');

//return an array of objects according to key, value, or key and value matching
function getObjects(obj, key, val) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getObjects(obj[i], key, val));
        } else
            //if key matches and value matches or if key matches and value is not passed (eliminating the case where key matches but passed value does not)
            if (i == key && obj[i] == val || i == key && val == '') { //
                objects.push(obj);
            } else if (obj[i] == val && key == '') {
            //only add if the object is not already in the array
            if (objects.lastIndexOf(obj) == -1) {
                objects.push(obj);
            }
        }
    }
    return objects;
}

//return an array of values that match on a certain key
function getValues(obj, key) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getValues(obj[i], key));
        } else if (i == key) {
            objects.push(obj[i]);
        }
    }
    return objects;
}

//return an array of keys that match on a certain value
function getKeys(obj, val) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getKeys(obj[i], val));
        } else if (obj[i] == val) {
            objects.push(i);
        }
    }
    return objects;
}

//http://techslides.com/how-to-parse-and-search-json-in-javascript	


var hasOwnProperty = Object.prototype.hasOwnProperty;

function isEmpty(obj) {

    // null and undefined are "empty"
    if (obj == null) return true;

    // Assume if it has a length property with a non-zero value
    // that that property is correct.
    if (obj.length > 0) return false;
    if (obj.length === 0) return true;

    // If it isn't an object at this point
    // it is empty, but it can't be anything *but* empty
    // Is it empty?  Depends on your application.
    if (typeof obj !== "object") return true;

    // Otherwise, does it have any properties of its own?
    // Note that this doesn't handle
    // toString and valueOf enumeration bugs in IE < 9
    for (var key in obj) {
        if (hasOwnProperty.call(obj, key)) return false;
    }

    return true;
}


function* countryInfo(query) {


    if (query.includes('what is the population of') || query.includes('what is the population of') || query.includes('what is the population for') || query.includes('what is the population for') || query.includes('what is the population of') || query.includes('what is the population of') || query.includes('what is the population for') || query.includes('what is the population for') || query.includes('what is the population of') || query.includes('what is the population of') || query.includes('what is the population for') || query.includes('what is the population for') || query.includes('tell me the population of') || query.includes('tell me the population of') || query.includes('tell me the population for') || query.includes('tell me the population for') || query.includes('tell me the population of') || query.includes('tell me the population of') || query.includes('tell me the population for') || query.includes('tell me the population for') || query.includes('tell me the population of') || query.includes('tell me the population of') || query.includes('tell me the population for') || query.includes('tell me the population for') || query.includes('What\'s the population of') || query.includes('What\'s the population of') || query.includes('What\'s the population for') || query.includes('What\'s the population for') || query.includes('What\'s the population of') || query.includes('What\'s the population of') || query.includes('What\'s the population for') || query.includes('What\'s the population for') || query.includes('What\'s the population of') || query.includes('What\'s the population of') || query.includes('What\'s the population for') || query.includes('What\'s the population for') || query.includes('get the population of') || query.includes('get the population of') || query.includes('get the population for') || query.includes('get the population for') || query.includes('get the population of') || query.includes('get the population of') || query.includes('get the population for') || query.includes('get the population for') || query.includes('get the population of') || query.includes('get the population of') || query.includes('get the population for') || query.includes('get the population for') || query.includes('get me the population of') || query.includes('get me the population of') || query.includes('get me the population for') || query.includes('get me the population for') || query.includes('get me the population of') || query.includes('get me the population of') || query.includes('get me the population for') || query.includes('get me the population for') || query.includes('get me the population of') || query.includes('get me the population of') || query.includes('get me the population for') || query.includes('get me the population for') || query.includes('tell the population of') || query.includes('tell the population of') || query.includes('tell the population for') || query.includes('tell the population for') || query.includes('tell the population of') || query.includes('tell the population of') || query.includes('tell the population for') || query.includes('tell the population for') || query.includes('tell the population of') || query.includes('tell the population of') || query.includes('tell the population for') || query.includes('tell the population for') || query.includes('population for') || query.includes('population for') || query.includes('population of') || query.includes('population of') || query.includes('what is the area of') || query.includes('what is the area of') || query.includes('what is the area for') || query.includes('what is the area for') || query.includes('what is the area of') || query.includes('what is the area of') || query.includes('what is the area for') || query.includes('what is the area for') || query.includes('what is the area of') || query.includes('what is the area of') || query.includes('what is the area for') || query.includes('what is the area for') || query.includes('tell me the area of') || query.includes('tell me the area of') || query.includes('tell me the area for') || query.includes('tell me the area for') || query.includes('tell me the area of') || query.includes('tell me the area of') || query.includes('tell me the area for') || query.includes('tell me the area for') || query.includes('tell me the area of') || query.includes('tell me the area of') || query.includes('tell me the area for') || query.includes('tell me the area for') || query.includes('What\'s the area of') || query.includes('What\'s the area of') || query.includes('What\'s the area for') || query.includes('What\'s the area for') || query.includes('What\'s the area of') || query.includes('What\'s the area of') || query.includes('What\'s the area for') || query.includes('What\'s the area for') || query.includes('What\'s the area of') || query.includes('What\'s the area of') || query.includes('What\'s the area for') || query.includes('What\'s the area for') || query.includes('get the area of') || query.includes('get the area of') || query.includes('get the area for') || query.includes('get the area for') || query.includes('get the area of') || query.includes('get the area of') || query.includes('get the area for') || query.includes('get the area for') || query.includes('get the area of') || query.includes('get the area of') || query.includes('get the area for') || query.includes('get the area for') || query.includes('get me the area of') || query.includes('get me the area of') || query.includes('get me the area for') || query.includes('get me the area for') || query.includes('get me the area of') || query.includes('get me the area of') || query.includes('get me the area for') || query.includes('get me the area for') || query.includes('get me the area of') || query.includes('get me the area of') || query.includes('get me the area for') || query.includes('get me the area for') || query.includes('tell the area of') || query.includes('tell the area of') || query.includes('tell the area for') || query.includes('tell the area for') || query.includes('tell the area of') || query.includes('tell the area of') || query.includes('tell the area for') || query.includes('tell the area for') || query.includes('tell the area of') || query.includes('tell the area of') || query.includes('tell the area for') || query.includes('tell the area for') || query.includes('area for') || query.includes('area for') || query.includes('area of') || query.includes('area of') || query.includes('what is the subregion of') || query.includes('what is the subregion of') || query.includes('what is the subregion for') || query.includes('what is the subregion for') || query.includes('what is the subregion of') || query.includes('what is the subregion of') || query.includes('what is the subregion for') || query.includes('what is the subregion for') || query.includes('what is the subregion of') || query.includes('what is the subregion of') || query.includes('what is the subregion for') || query.includes('what is the subregion for') || query.includes('tell me the subregion of') || query.includes('tell me the subregion of') || query.includes('tell me the subregion for') || query.includes('tell me the subregion for') || query.includes('tell me the subregion of') || query.includes('tell me the subregion of') || query.includes('tell me the subregion for') || query.includes('tell me the subregion for') || query.includes('tell me the subregion of') || query.includes('tell me the subregion of') || query.includes('tell me the subregion for') || query.includes('tell me the subregion for') || query.includes('What\'s the subregion of') || query.includes('What\'s the subregion of') || query.includes('What\'s the subregion for') || query.includes('What\'s the subregion for') || query.includes('What\'s the subregion of') || query.includes('What\'s the subregion of') || query.includes('What\'s the subregion for') || query.includes('What\'s the subregion for') || query.includes('What\'s the subregion of') || query.includes('What\'s the subregion of') || query.includes('What\'s the subregion for') || query.includes('What\'s the subregion for') || query.includes('get the subregion of') || query.includes('get the subregion of') || query.includes('get the subregion for') || query.includes('get the subregion for') || query.includes('get the subregion of') || query.includes('get the subregion of') || query.includes('get the subregion for') || query.includes('get the subregion for') || query.includes('get the subregion of') || query.includes('get the subregion of') || query.includes('get the subregion for') || query.includes('get the subregion for') || query.includes('get me the subregion of') || query.includes('get me the subregion of') || query.includes('get me the subregion for') || query.includes('get me the subregion for') || query.includes('get me the subregion of') || query.includes('get me the subregion of') || query.includes('get me the subregion for') || query.includes('get me the subregion for') || query.includes('get me the subregion of') || query.includes('get me the subregion of') || query.includes('get me the subregion for') || query.includes('get me the subregion for') || query.includes('tell the subregion of') || query.includes('tell the subregion of') || query.includes('tell the subregion for') || query.includes('tell the subregion for') || query.includes('tell the subregion of') || query.includes('tell the subregion of') || query.includes('tell the subregion for') || query.includes('tell the subregion for') || query.includes('tell the subregion of') || query.includes('tell the subregion of') || query.includes('tell the subregion for') || query.includes('tell the subregion for') || query.includes('subregion for') || query.includes('subregion for') || query.includes('subregion of') || query.includes('subregion of') || query.includes('what is the continent of') || query.includes('what is the continent of') || query.includes('what is the continent for') || query.includes('what is the continent for') || query.includes('what is the continent of') || query.includes('what is the continent of') || query.includes('what is the continent for') || query.includes('what is the continent for') || query.includes('what is the continent of') || query.includes('what is the continent of') || query.includes('what is the continent for') || query.includes('what is the continent for') || query.includes('tell me the continent of') || query.includes('tell me the continent of') || query.includes('tell me the continent for') || query.includes('tell me the continent for') || query.includes('tell me the continent of') || query.includes('tell me the continent of') || query.includes('tell me the continent for') || query.includes('tell me the continent for') || query.includes('tell me the continent of') || query.includes('tell me the continent of') || query.includes('tell me the continent for') || query.includes('tell me the continent for') || query.includes('What\'s the continent of') || query.includes('What\'s the continent of') || query.includes('What\'s the continent for') || query.includes('What\'s the continent for') || query.includes('What\'s the continent of') || query.includes('What\'s the continent of') || query.includes('What\'s the continent for') || query.includes('What\'s the continent for') || query.includes('What\'s the continent of') || query.includes('What\'s the continent of') || query.includes('What\'s the continent for') || query.includes('What\'s the continent for') || query.includes('get the continent of') || query.includes('get the continent of') || query.includes('get the continent for') || query.includes('get the continent for') || query.includes('get the continent of') || query.includes('get the continent of') || query.includes('get the continent for') || query.includes('get the continent for') || query.includes('get the continent of') || query.includes('get the continent of') || query.includes('get the continent for') || query.includes('get the continent for') || query.includes('get me the continent of') || query.includes('get me the continent of') || query.includes('get me the continent for') || query.includes('get me the continent for') || query.includes('get me the continent of') || query.includes('get me the continent of') || query.includes('get me the continent for') || query.includes('get me the continent for') || query.includes('get me the continent of') || query.includes('get me the continent of') || query.includes('get me the continent for') || query.includes('get me the continent for') || query.includes('tell the continent of') || query.includes('tell the continent of') || query.includes('tell the continent for') || query.includes('tell the continent for') || query.includes('tell the continent of') || query.includes('tell the continent of') || query.includes('tell the continent for') || query.includes('tell the continent for') || query.includes('tell the continent of') || query.includes('tell the continent of') || query.includes('tell the continent for') || query.includes('tell the continent for') || query.includes('continent for') || query.includes('continent for') || query.includes('continent of') || query.includes('continent of') || query.includes('to which continent') || query.includes('what is the continent of') || query.includes('what is the continent of') || query.includes('what is the continent for') || query.includes('what is the continent for') || query.includes('what is the continent of') || query.includes('what is the continent of') || query.includes('what is the continent for') || query.includes('what is the continent for') || query.includes('what is the continent of') || query.includes('what is the continent of') || query.includes('what is the continent for') || query.includes('what is the continent for') || query.includes('tell me the continent of') || query.includes('tell me the continent of') || query.includes('tell me the continent for') || query.includes('tell me the continent for') || query.includes('tell me the continent of') || query.includes('tell me the continent of') || query.includes('tell me the continent for') || query.includes('tell me the continent for') || query.includes('tell me the continent of') || query.includes('tell me the continent of') || query.includes('tell me the continent for') || query.includes('tell me the continent for') || query.includes('What\'s the continent of') || query.includes('What\'s the continent of') || query.includes('What\'s the continent for') || query.includes('What\'s the continent for') || query.includes('What\'s the continent of') || query.includes('What\'s the continent of') || query.includes('What\'s the continent for') || query.includes('What\'s the continent for') || query.includes('What\'s the continent of') || query.includes('What\'s the continent of') || query.includes('What\'s the continent for') || query.includes('What\'s the continent for') || query.includes('get the continent of') || query.includes('get the continent of') || query.includes('get the continent for') || query.includes('get the continent for') || query.includes('get the continent of') || query.includes('get the continent of') || query.includes('get the continent for') || query.includes('get the continent for') || query.includes('get the continent of') || query.includes('get the continent of') || query.includes('get the continent for') || query.includes('get the continent for') || query.includes('get me the continent of') || query.includes('get me the continent of') || query.includes('get me the continent for') || query.includes('get me the continent for') || query.includes('get me the continent of') || query.includes('get me the continent of') || query.includes('get me the continent for') || query.includes('get me the continent for') || query.includes('get me the continent of') || query.includes('get me the continent of') || query.includes('get me the continent for') || query.includes('get me the continent for') || query.includes('tell the continent of') || query.includes('tell the continent of') || query.includes('tell the continent for') || query.includes('tell the continent for') || query.includes('tell the continent of') || query.includes('tell the continent of') || query.includes('tell the continent for') || query.includes('tell the continent for') || query.includes('tell the continent of') || query.includes('tell the continent of') || query.includes('tell the continent for') || query.includes('tell the continent for') || query.includes('continent for') || query.includes('continent for') || query.includes('continent of') || query.includes('continent of') || query.includes('to which continent')

    ) {


        let country = "India",
            query2 = null;
        var countryPopulation = null,
            countryArea = null,
            countrySubregion = null;


        if (query.includes('population of') || query.includes('area of') || query.includes('subregion of') || query.includes('continent of')) {
            country = query.split("of")[1].trim();
        } else if (query.includes('population for') || query.includes('area for') || query.includes('subregion for') || query.includes('continent for')) {
            country = query.split("for")[1].trim();
        } else if (query.includes('to which continent')) {
            query2 = query;
            query = query.split("continent")[1].trim();
            country = query.split("belong")[0].trim();
        }

        country = country.charAt(0).toUpperCase() + country.slice(1);
        console.log("country: " + country);

        if (country == 'America') {
            country = "United States of America";
        }

        const restcountries_url = 'https://restcountries.eu/rest/v2/name/' + country + '?fullText=true'
        let data = yield request(restcountries_url)
        data = JSON.parse(data.body)

        if (country == 'Uk') {
            country = "United Kingdom of Great Britain and Northern Ireland";
        } else if (country == 'Us' || country == 'Usa' || country == 'America') {
            country = "United States of America";
        }

        console.log("hii: " + isEmpty(getObjects(data, 'name', country)));

        console.log("hii222222222222: " + typeof getObjects(data, 'name', country));
        if (isEmpty(getObjects(data, 'name', country))) {
            console.log("empty");




            const cities = require("all-the-cities")

            let d = cities.filter(city => {
                return city.name.match(country)
            });

            //d = JSON.parse(d.body);

            console.log("d: " + d);
            var city = country;
	    var string="";	

            for (var key in d) {
                var value = d[key];
                console.log(value.country.toString());
                console.log(value.population.toString());

console.log(value.altCountry);
console.log(value.muni);
console.log(value.muniSub);

                country = value.country.toString();
                countryPopulation = value.population.toString();
		string = string + "Population of the city " + city + " in the country of " + country + " is " + countryPopulation + "  ";
            }

            

            if (countryPopulation !== null && typeof countryPopulation !== 'object') {
		
                return {
                    text: string
                }

            }




        }
        let data2 = getObjects(data, 'name', country);
        console.log("hii2: " + isEmpty(getObjects(data2, 'name', country)));
        console.log("hii33333333333333333: " + typeof getObjects(data2, 'name', country));

        if (isEmpty(getObjects(data2, 'name', country))) {
            console.log("empty");
        }

        let data3 = getObjects(data2, 'name', country);


        for (var key in data3) {
            var value = data3[key];

            if (query.includes('population of') || query.includes('population for')) {
                console.log(value.population.toString());
                countryPopulation = value.population.toString();
            } else if (query.includes('area of') || query.includes('area for')) {
                console.log(value.area.toString());
                countryArea = value.area.toString();
                console.log("countryArea: " + countryArea);
            } else if (query.includes('subregion of') || query.includes('subregion for') || query.includes('continent of') || query.includes('continent for') || query2.includes('to which continent')) {
                console.log(value.subregion.toString());
                countrySubregion = value.subregion.toString();
            }


        }




        if (countryPopulation !== null && typeof countryPopulation !== 'object') {

            return {
                text: "Population of " + country + " is " + countryPopulation
            }

        } else if (countryArea !== null && typeof countryArea !== 'object') {

            return {
                text: "Area of " + country + " is " + countryArea + " square kilometers"
            }

        } else if (countrySubregion !== null && typeof countrySubregion !== 'object') {

            return {
                text: "Continent to which " + country + " belong is " + countrySubregion
            }

        }



    }


}

const intent = () => ({
    keywords: ["dialing calling"],
    module: 'countryOtherDetails'
})

const examples = () => (
    []
)

module.exports = {
    get: countryInfo,
    hardRule
    //,examples
}
