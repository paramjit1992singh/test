function * medicine_resp(query) {

var medicineName=query.split('sideeffects of')[1].trim();

var request = require('request');

var accessToken = '9545c7a36362fb33f490428f7994d496e0dcfbf000027a662d3f4eec5c77a363 ';

request({
  url: 'http://www.healthos.co/api/v1/search/diseases/{{'+medicineName+'}}',
  auth: {
    'bearer': accessToken
  }
}, function(err, res) {
  console.log(res.body);
});    



return {text: 'Hello World'}

}

const intent = () => ({
    keywords: ["medical sideeffects"], module: 'medicine_sideEffects'
})

const examples = () => (
    []
)

module.exports = {
    get: medicine_resp,
    intent,
    examples
}
