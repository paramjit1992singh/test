function* system_Volume(query) {

    let defaultVolume = "";
    let defaultMute = "false";

    if (query.includes('increase volume') || (query.startsWith('volume up') || query.startsWith('decrease volume')) || query.startsWith('volume down') || query.startsWith('mute') || query.startsWith('un mute') || query.startsWith('unmute') || query.startsWith('un-mute') || query.startsWith('max volume') || query.startsWith('maximum volume') || query.startsWith('full volume') || query.startsWith('min volume') || query.startsWith('minimum volume') || query.includes('turn up the volume') || query.includes('turn down the volume') || query.includes('set volume to') || query.includes('louder') || query.includes('silent')) {


        var loudness = require('loudness');


        if (query.includes('increase volume') || query.includes('turn up the volume') || query.includes('louder')) {

            loudness.getVolume(function(err, vol) {
                // vol = 45 
                defaultVolume = vol;
                console.log("defaultVolume: " + defaultVolume);



                defaultVolume = defaultVolume + 25;
                console.log("new defaultVolume: " + defaultVolume);

                loudness.setVolume(defaultVolume, function(err) {
                    console.log("new increased defaultVolume: " + defaultVolume);
                    // Done 

                });



            });



        } else if (query.includes('volume up')) {

            loudness.getVolume(function(err, vol) {
                // vol = 45 
                defaultVolume = vol;
                console.log("defaultVolume: " + defaultVolume);

                defaultVolume = defaultVolume + 25;
                console.log("new defaultVolume: " + defaultVolume);
                loudness.setVolume(defaultVolume, function(err) {
                    console.log("new increased defaultVolume: " + defaultVolume);
                    // Done 

                });


            });



        } else if (query.includes('decrease volume') || query.includes('turn down the volume')) {

            loudness.getVolume(function(err, vol) {
                // vol = 45 
                defaultVolume = vol;
                console.log("defaultVolume: " + defaultVolume);

                defaultVolume = defaultVolume - 25;

                loudness.setVolume(defaultVolume, function(err) {
                    console.log("new decreased defaultVolume: " + defaultVolume);
                    // Done 

                });

            });



        } else if (query.includes('volume down')) {

            loudness.getVolume(function(err, vol) {
                // vol = 45 
                defaultVolume = vol;
                console.log("defaultVolume: " + defaultVolume);

                defaultVolume = defaultVolume - 25;

                loudness.setVolume(defaultVolume, function(err) {
                    console.log("new decreased defaultVolume: " + defaultVolume);
                    // Done 

                });

            });



        } else if (query.includes('mute') || query.includes('silent')) {


            loudness.getMuted(function(err, mute) {
                // mute = false
                defaultMute = mute;

                defaultMute = "true";

                loudness.setMuted(defaultMute, function(err) {
                    // Done 
                    console.log("new defaultMute: " + defaultMute);
                    // Done 

                });

            });



        } else if (query.startsWith('un mute') || query.startsWith('unmute') || query.startsWith('un-mute')) {


            loudness.getMuted(function(err, mute) {
                // mute = false
                defaultMute = mute;


                defaultMute = "false";

                loudness.setMuted(defaultMute, function(err) {
                    // Done 
                    console.log("new defaultMute: " + defaultMute);
                    // Done 

                });

            });



        } else if (query.includes('max volume') || query.includes('maximum volume') || query.includes('full volume')) {

            loudness.setVolume(100, function(err) {
                // Done 
            });


        } else if (query.includes('min volume') || query.includes('minimum volume')) {

            loudness.setVolume(25, function(err) {
                // Done 
            });


        }




        /*loudness.setMuted(false, function (err) {
            // Done 
        });
         
        loudness.getMuted(function (err, mute) {
            // mute = false 
        });*/


    }


    return {
        text: 'Sir it\'s done'
    }
}

const intent = () => ({
    keywords: ["increase volume", "volume up", "decrease volume", "volume down", "full volume","mute","unmute","un mute","un-mute","max volume", "min volume","maximum volume","minimum volume","turn up the volume","turn down the volume","set volume to","louder","silent"],
    module: 'systemVolume'
})

const examples = () => (
    []
)

module.exports = {
    get: system_Volume,
    intent,
    examples
}
