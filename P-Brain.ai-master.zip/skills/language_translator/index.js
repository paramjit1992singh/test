function* languageTranslator(query) {

    let defaultLanguage = "english";
    let defaultText = "";

    if (query.includes('translate') && (query.includes("to afrikaans") || query.includes("to albanian") || query.includes("to arabic") || query.includes("to armenian") || query.includes("to azerbaijani") || query.includes("to basque") || query.includes("to belarusian") || query.includes("to bulgarian") || query.includes("to catalan") || query.includes("to chinese	simplified") || query.includes("to chinese traditional") || query.includes("to croatian") || query.includes("to czech") || query.includes("to danish") || query.includes("to dutch") || query.includes("to english") || query.includes("to estonian") || query.includes("to filipino") || query.includes("to finnish") || query.includes("to french") || query.includes("to galician") || query.includes("to georgian") || query.includes("to german") || query.includes("to greek") || query.includes("to haitian creole") || query.includes("to hebrew") || query.includes("to hindi") || query.includes("to icelandic") || query.includes("to indonesian") || query.includes("to irish") || query.includes("to italian") || query.includes("to japanese") || query.includes("to korean") || query.includes("to latvian") || query.includes("to lithuanian") || query.includes("to macedonian") || query.includes("to malay") || query.includes("to maltese") || query.includes("to norwegian") || query.includes("to persian") || query.includes("to polish") || query.includes("to portuguese") || query.includes("to romanian") || query.includes("to russian") || query.includes("to serbian") || query.includes("to slovak") || query.includes("to slovenian") || query.includes("to spanish") || query.includes("to swahili") || query.includes("to swedish") || query.includes("to thai") || query.includes("to turkish") || query.includes("to ukrainian") || query.includes("to urdu") || query.includes("to vietnamese") || query.includes("to welsh") || query.includes("to yiddish"))) {

        query = query.split('translate')[1].trim();


        if (query.includes("to afrikaans") || query.includes("to albanian") || query.includes("to arabic") || query.includes("to armenian") || query.includes("to azerbaijani") || query.includes("to basque") || query.includes("to belarusian") || query.includes("to bulgarian") || query.includes("to catalan") || query.includes("to chinese simplified") || query.includes("to chinese traditional") || query.includes("to croatian") || query.includes("to czech") || query.includes("to danish") || query.includes("to dutch") || query.includes("to english") || query.includes("to estonian") || query.includes("to filipino") || query.includes("to finnish") || query.includes("to french") || query.includes("to galician") || query.includes("to georgian") || query.includes("to german") || query.includes("to greek") || query.includes("to haitian creole") || query.includes("to hebrew") || query.includes("to hindi") || query.includes("to hungarian") || query.includes("to icelandic") || query.includes("to indonesian") || query.includes("to irish") || query.includes("to italian") || query.includes("to japanese") || query.includes("to korean") || query.includes("to latvian") || query.includes("to lithuanian") || query.includes("to macedonian") || query.includes("to malay") || query.includes("to maltese") || query.includes("to norwegian") || query.includes("to persian") || query.includes("to polish") || query.includes("to portuguese") || query.includes("to romanian") || query.includes("to russian") || query.includes("to serbian") || query.includes("to slovak") || query.includes("to slovenian") || query.includes("to spanish") || query.includes("to swahili") || query.includes("to swedish") || query.includes("to thai") || query.includes("to turkish") || query.includes("to ukrainian") || query.includes("to urdu") || query.includes("to vietnamese") || query.includes("to welsh") || query.includes("to yiddish")) {


            /*defaultText = (query.split("to afrikaans")[0].trim() || query.split("to albanian")[0].trim() || query.split("to arabic")[0].trim() || query.split("to armenian")[0].trim() || query.split("to azerbaijani")[0].trim() || query.split("to basque")[0].trim() || query.split("to belarusian")[0].trim() || query.split("to bulgarian")[0].trim() || query.split("to catalan")[0].trim() || query.split("to chinese	simplified")[0].trim() || query.split("to chinese traditional")[0].trim() || query.split("to croatian")[0].trim() || query.split("to czech")[0].trim() || query.split("to danish")[0].trim() || query.split("to dutch")[0].trim() || query.split("to english")[0].trim() || query.split("to estonian")[0].trim() || query.split("to filipino")[0].trim() || query.split("to finnish")[0].trim() || query.split("to french")[0].trim() || query.split("to galician")[0].trim() || query.split("to georgian")[0].trim() || query.split("to german")[0].trim() || query.split("to greek")[0].trim() || query.split("to haitian creole")[0].trim() || query.split("to hebrew")[0].trim() || query.split("to hindi")[0].trim() || query.split("to hungarian")[0].trim() || query.split("to icelandic")[0].trim() || query.split("to indonesian")[0].trim() || query.split("to irish")[0].trim() || query.split("to italian")[0].trim() || query.split("to japanese")[0].trim() || query.split("to korean")[0].trim() || query.split("to latvian")[0].trim() || query.split("to lithuanian")[0].trim() || query.split("to macedonian")[0].trim() || query.split("to malay")[0].trim() || query.split("to maltese")[0].trim() || query.split("to norwegian")[0].trim() || query.split("to persian")[0].trim() || query.split("to polish")[0].trim() || query.split("to portuguese")[0].trim() || query.split("to romanian")[0].trim() || query.split("to russian")[0].trim() || query.split("to serbian")[0].trim() || query.split("to slovak")[0].trim() || query.split("to slovenian")[0].trim() || query.split("to spanish")[0].trim() || query.split("to swahili")[0].trim() || query.split("to swedish")[0].trim() || query.split("to thai")[0].trim() || query.split("to turkish")[0].trim() || query.split("to ukrainian")[0].trim() || query.split("to urdu")[0].trim() || query.split("to vietnamese")[0].trim() || query.split("to welsh")[0].trim() || query.split("to yiddish"));*/


defaultText=query.split("to")[0].trim();
 defaultLanguage = query.split("to")[1].trim();
           // defaultLanguage = query.slice(query.lastIndexOf(' ') + 1);
            defaultLanguage = defaultLanguage.charAt(0).toUpperCase() + defaultLanguage.slice(1);

            console.log("defaultText: " + defaultText);
            console.log("defaultLanguage: " + defaultLanguage);

            let sys = require('util');
            let colors = require('colors'); // colors are fun!
            let translate = require('./lib/translate');

            let input = 'English',
                output = defaultLanguage;
            translate.text({
                input: input,
                output: output
            }, defaultText, function(err, text2) {

                /*sys.puts(text2, 'Good News', 1.0, function(err) {
                    if (err) {
                        return console.error(err);
                    }

                    console.log('Text has been spoken.');
                });*/

console.log("text2: "+text2);
                return {

                    text: text2
                }



            });

        }

    }

      return {   text: 'Message Sent'}

}

const intent = () => ({
    keywords: ["translate"],
    module: 'language_translator'
})

const examples = () => (
    []
)

module.exports = {
    get: languageTranslator,
    intent,
    examples
}
