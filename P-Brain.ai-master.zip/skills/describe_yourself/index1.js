function * describe_yourself() {
    return {text: 'I Am SAM! , An Intelligent Personal Assistant, Designed And Developed By Paramjit'}
}

const intent = () => ({
    keywords: ["describe yourself","who are you","what is your name","what is sam"], module: 'describe_yourself'
})

const examples = () => (
    []
)

module.exports = {
    get: describe_yourself,
    intent,
    examples
}
