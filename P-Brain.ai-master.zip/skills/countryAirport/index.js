function hardRule(query, breakdown) {
    return (query.startsWith('what is the phone number of') || query.startsWith('what is the email address of') || query.startsWith('what is the phone number for') || query.startsWith('what is the email address for') || query.startsWith('what is the phone number of') || query.startsWith('what is the email address of') || query.startsWith('what is the phone number for') || query.startsWith('what is the email address for') || query.startsWith('what is the phone number of') || query.startsWith('what is the email address of') || query.startsWith('what is the phone number for') || query.startsWith('what is the email address for') || query.startsWith('tell me the phone number of') || query.startsWith('tell me the email address of') || query.startsWith('tell me the phone number for') || query.startsWith('tell me the email address for') || query.startsWith('tell me the phone number of') || query.startsWith('tell me the email address of') || query.startsWith('tell me the phone number for') || query.startsWith('tell me the email address for') || query.startsWith('tell me the phone number of') || query.startsWith('tell me the email address of') || query.startsWith('tell me the phone number for') || query.startsWith('tell me the email address for') || query.startsWith('What\'s the phone number of') || query.startsWith('What\'s the email address of') || query.startsWith('What\'s the phone number for') || query.startsWith('What\'s the email address for') || query.startsWith('What\'s the phone number of') || query.startsWith('What\'s the email address of') || query.startsWith('What\'s the phone number for') || query.startsWith('What\'s the email address for') || query.startsWith('What\'s the phone number of') || query.startsWith('What\'s the email address of') || query.startsWith('What\'s the phone number for') || query.startsWith('What\'s the email address for') || query.startsWith('get the phone number of') || query.startsWith('get the email address of') || query.startsWith('get the phone number for') || query.startsWith('get the email address for') || query.startsWith('get the phone number of') || query.startsWith('get the email address of') || query.startsWith('get the phone number for') || query.startsWith('get the email address for') || query.startsWith('get the phone number of') || query.startsWith('get the email address of') || query.startsWith('get the phone number for') || query.startsWith('get the email address for') || query.startsWith('get me the phone number of') || query.startsWith('get me the email address of') || query.startsWith('get me the phone number for') || query.startsWith('get me the email address for') || query.startsWith('get me the phone number of') || query.startsWith('get me the email address of') || query.startsWith('get me the phone number for') || query.startsWith('get me the email address for') || query.startsWith('get me the phone number of') || query.startsWith('get me the email address of') || query.startsWith('get me the phone number for') || query.startsWith('get me the email address for') || query.startsWith('tell the phone number of') || query.startsWith('tell the email address of') || query.startsWith('tell the phone number for') || query.startsWith('tell the email address for') || query.startsWith('tell the phone number of') || query.startsWith('tell the email address of') || query.startsWith('tell the phone number for') || query.startsWith('tell the email address for') || query.startsWith('tell the phone number of') || query.startsWith('tell the email address of') || query.startsWith('tell the phone number for') || query.startsWith('tell the email address for') || query.startsWith('phone number for') || query.startsWith('email address for') || query.startsWith('phone number of') || query.startsWith('email address of') || query.startsWith('what is the location of') || query.startsWith('what is the airport code of') || query.startsWith('what is the location for') || query.startsWith('what is the airport code for') || query.startsWith('what is the location of') || query.startsWith('what is the airport code of') || query.startsWith('what is the location for') || query.startsWith('what is the airport code for') || query.startsWith('what is the location of') || query.startsWith('what is the airport code of') || query.startsWith('what is the location for') || query.startsWith('what is the airport code for') || query.startsWith('tell me the location of') || query.startsWith('tell me the airport code of') || query.startsWith('tell me the location for') || query.startsWith('tell me the airport code for') || query.startsWith('tell me the location of') || query.startsWith('tell me the airport code of') || query.startsWith('tell me the location for') || query.startsWith('tell me the airport code for') || query.startsWith('tell me the location of') || query.startsWith('tell me the airport code of') || query.startsWith('tell me the location for') || query.startsWith('tell me the airport code for') || query.startsWith('What\'s the location of') || query.startsWith('What\'s the airport code of') || query.startsWith('What\'s the location for') || query.startsWith('What\'s the airport code for') || query.startsWith('What\'s the location of') || query.startsWith('What\'s the airport code of') || query.startsWith('What\'s the location for') || query.startsWith('What\'s the airport code for') || query.startsWith('What\'s the location of') || query.startsWith('What\'s the airport code of') || query.startsWith('What\'s the location for') || query.startsWith('What\'s the airport code for') || query.startsWith('get the location of') || query.startsWith('get the airport code of') || query.startsWith('get the location for') || query.startsWith('get the airport code for') || query.startsWith('get the location of') || query.startsWith('get the airport code of') || query.startsWith('get the location for') || query.startsWith('get the airport code for') || query.startsWith('get the location of') || query.startsWith('get the airport code of') || query.startsWith('get the location for') || query.startsWith('get the airport code for') || query.startsWith('get me the location of') || query.startsWith('get me the airport code of') || query.startsWith('get me the location for') || query.startsWith('get me the airport code for') || query.startsWith('get me the location of') || query.startsWith('get me the airport code of') || query.startsWith('get me the location for') || query.startsWith('get me the airport code for') || query.startsWith('get me the location of') || query.startsWith('get me the airport code of') || query.startsWith('get me the location for') || query.startsWith('get me the airport code for') || query.startsWith('tell the location of') || query.startsWith('tell the airport code of') || query.startsWith('tell the location for') || query.startsWith('tell the airport code for') || query.startsWith('tell the location of') || query.startsWith('tell the airport code of') || query.startsWith('tell the location for') || query.startsWith('tell the airport code for') || query.startsWith('tell the location of') || query.startsWith('tell the airport code of') || query.startsWith('tell the location for') || query.startsWith('tell the airport code for') || query.startsWith('location for') || query.startsWith('airport code for') || query.startsWith('location of') || query.startsWith('airport code of') || query.startsWith('what is the runway length of') || query.startsWith('how long is the runway length of') || query.startsWith('how many direct flights are there to') || query.startsWith('what is the where on earth id of') || query.startsWith('what is the runway length for') || query.startsWith('what is the where on earth id for') || query.startsWith('what is the runway length of') || query.startsWith('what is the where on earth id of') || query.startsWith('what is the runway length for') || query.startsWith('what is the where on earth id for') || query.startsWith('what is the runway length of') || query.startsWith('what is the where on earth id of') || query.startsWith('what is the runway length for') || query.startsWith('what is the where on earth id for') || query.startsWith('tell me the runway length of') || query.startsWith('tell me the where on earth id of') || query.startsWith('tell me the runway length for') || query.startsWith('tell me the where on earth id for') || query.startsWith('tell me the runway length of') || query.startsWith('tell me the where on earth id of') || query.startsWith('tell me the runway length for') || query.startsWith('tell me the where on earth id for') || query.startsWith('tell me the runway length of') || query.startsWith('tell me the where on earth id of') || query.startsWith('tell me the runway length for') || query.startsWith('tell me the where on earth id for') || query.startsWith('What\'s the runway length of') || query.startsWith('What\'s the where on earth id of') || query.startsWith('What\'s the runway length for') || query.startsWith('What\'s the where on earth id for') || query.startsWith('What\'s the runway length of') || query.startsWith('What\'s the where on earth id of') || query.startsWith('What\'s the runway length for') || query.startsWith('What\'s the where on earth id for') || query.startsWith('What\'s the runway length of') || query.startsWith('What\'s the where on earth id of') || query.startsWith('What\'s the runway length for') || query.startsWith('What\'s the where on earth id for') || query.startsWith('get the runway length of') || query.startsWith('get the where on earth id of') || query.startsWith('get the runway length for') || query.startsWith('get the where on earth id for') || query.startsWith('get the runway length of') || query.startsWith('get the where on earth id of') || query.startsWith('get the runway length for') || query.startsWith('get the where on earth id for') || query.startsWith('get the runway length of') || query.startsWith('get the where on earth id of') || query.startsWith('get the runway length for') || query.startsWith('get the where on earth id for') || query.startsWith('get me the runway length of') || query.startsWith('get me the where on earth id of') || query.startsWith('get me the runway length for') || query.startsWith('get me the where on earth id for') || query.startsWith('get me the runway length of') || query.startsWith('get me the where on earth id of') || query.startsWith('get me the runway length for') || query.startsWith('get me the where on earth id for') || query.startsWith('get me the runway length of') || query.startsWith('get me the where on earth id of') || query.startsWith('get me the runway length for') || query.startsWith('get me the where on earth id for') || query.startsWith('tell the runway length of') || query.startsWith('tell the where on earth id of') || query.startsWith('tell the runway length for') || query.startsWith('tell the where on earth id for') || query.startsWith('tell the runway length of') || query.startsWith('tell the where on earth id of') || query.startsWith('tell the runway length for') || query.startsWith('tell the where on earth id for') || query.startsWith('tell the runway length of') || query.startsWith('tell the where on earth id of') || query.startsWith('tell the runway length for') || query.startsWith('tell the where on earth id for') || query.startsWith('runway length for') || query.startsWith(' where on earth id for') || query.startsWith('runway length of') || query.startsWith(' where on earth id of') || query.startsWith('what is the time zone of') || query.startsWith('what is the latitude and longitude of') || query.startsWith('what is the time zone for') || query.startsWith('what is the latitude and longitude for') || query.startsWith('what is the time zone of') || query.startsWith('what is the latitude and longitude of') || query.startsWith('what is the time zone for') || query.startsWith('what is the latitude and longitude for') || query.startsWith('what is the time zone of') || query.startsWith('what is the latitude and longitude of') || query.startsWith('what is the time zone for') || query.startsWith('what is the latitude and longitude for') || query.startsWith('tell me the time zone of') || query.startsWith('tell me the latitude and longitude of') || query.startsWith('tell me the time zone for') || query.startsWith('tell me the latitude and longitude for') || query.startsWith('tell me the time zone of') || query.startsWith('tell me the latitude and longitude of') || query.startsWith('tell me the time zone for') || query.startsWith('tell me the latitude and longitude for') || query.startsWith('tell me the time zone of') || query.startsWith('tell me the latitude and longitude of') || query.startsWith('tell me the time zone for') || query.startsWith('tell me the latitude and longitude for') || query.startsWith('What\'s the time zone of') || query.startsWith('What\'s the latitude and longitude of') || query.startsWith('What\'s the time zone for') || query.startsWith('What\'s the latitude and longitude for') || query.startsWith('What\'s the time zone of') || query.startsWith('What\'s the latitude and longitude of') || query.startsWith('What\'s the time zone for') || query.startsWith('What\'s the latitude and longitude for') || query.startsWith('What\'s the time zone of') || query.startsWith('What\'s the latitude and longitude of') || query.startsWith('What\'s the time zone for') || query.startsWith('What\'s the latitude and longitude for') || query.startsWith('get the time zone of') || query.startsWith('get the latitude and longitude of') || query.startsWith('get the time zone for') || query.startsWith('get the latitude and longitude for') || query.startsWith('get the time zone of') || query.startsWith('get the latitude and longitude of') || query.startsWith('get the time zone for') || query.startsWith('get the latitude and longitude for') || query.startsWith('get the time zone of') || query.startsWith('get the latitude and longitude of') || query.startsWith('get the time zone for') || query.startsWith('get the latitude and longitude for') || query.startsWith('get me the time zone of') || query.startsWith('get me the latitude and longitude of') || query.startsWith('get me the time zone for') || query.startsWith('get me the latitude and longitude for') || query.startsWith('get me the time zone of') || query.startsWith('get me the latitude and longitude of') || query.startsWith('get me the time zone for') || query.startsWith('get me the latitude and longitude for') || query.startsWith('get me the time zone of') || query.startsWith('get me the latitude and longitude of') || query.startsWith('get me the time zone for') || query.startsWith('get me the latitude and longitude for') || query.startsWith('tell the time zone of') || query.startsWith('tell the latitude and longitude of') || query.startsWith('tell the time zone for') || query.startsWith('tell the latitude and longitude for') || query.startsWith('tell the time zone of') || query.startsWith('tell the latitude and longitude of') || query.startsWith('tell the time zone for') || query.startsWith('tell the latitude and longitude for') || query.startsWith('tell the time zone of') || query.startsWith('tell the latitude and longitude of') || query.startsWith('tell the time zone for') || query.startsWith('tell the latitude and longitude for') || query.startsWith(' time zone for') || query.startsWith('latitude and longitude for') || query.startsWith(' time zone of') || query.startsWith('latitude and longitude of') ||query.startsWith('what is the website of') || query.startsWith('what is the url of') || query.startsWith('what is the website for') || query.startsWith('what is the url for') || query.startsWith('what is the website of') || query.startsWith('what is the url of') || query.startsWith('what is the website for') || query.startsWith('what is the url for') || query.startsWith('what is the website of') || query.startsWith('what is the url of') || query.startsWith('what is the website for') || query.startsWith('what is the url for') || query.startsWith('tell me the website of') || query.startsWith('tell me the url of') || query.startsWith('tell me the website for') || query.startsWith('tell me the url for') || query.startsWith('tell me the website of') || query.startsWith('tell me the url of') || query.startsWith('tell me the website for') || query.startsWith('tell me the url for') || query.startsWith('tell me the website of') || query.startsWith('tell me the url of') || query.startsWith('tell me the website for') || query.startsWith('tell me the url for') || query.startsWith('What\'s the website of') || query.startsWith('What\'s the url of') || query.startsWith('What\'s the website for') || query.startsWith('What\'s the url for') || query.startsWith('What\'s the website of') || query.startsWith('What\'s the url of') || query.startsWith('What\'s the website for') || query.startsWith('What\'s the url for') || query.startsWith('What\'s the website of') || query.startsWith('What\'s the url of') || query.startsWith('What\'s the website for') || query.startsWith('What\'s the url for') || query.startsWith('get the website of') || query.startsWith('get the url of') || query.startsWith('get the website for') || query.startsWith('get the url for') || query.startsWith('get the website of') || query.startsWith('get the url of') || query.startsWith('get the website for') || query.startsWith('get the url for') || query.startsWith('get the website of') || query.startsWith('get the url of') || query.startsWith('get the website for') || query.startsWith('get the url for') || query.startsWith('get me the website of') || query.startsWith('get me the url of') || query.startsWith('get me the website for') || query.startsWith('get me the url for') || query.startsWith('get me the website of') || query.startsWith('get me the url of') || query.startsWith('get me the website for') || query.startsWith('get me the url for') || query.startsWith('get me the website of') || query.startsWith('get me the url of') || query.startsWith('get me the website for') || query.startsWith('get me the url for') || query.startsWith('tell the website of') || query.startsWith('tell the url of') || query.startsWith('tell the website for') || query.startsWith('tell the url for') || query.startsWith('tell the website of') || query.startsWith('tell the url of')) && query.includes('airport')
}




const request = require('co-request');

//return an array of objects according to key, value, or key and value matching
function getObjects(obj, key, val) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getObjects(obj[i], key, val));
        } else
            //if key matches and value matches or if key matches and value is not passed (eliminating the case where key matches but passed value does not)
            if (i == key && obj[i] == val || i == key && val == '') { //
                objects.push(obj);
            } else if (obj[i] == val && key == '') {
            //only add if the object is not already in the array
            if (objects.lastIndexOf(obj) == -1) {
                objects.push(obj);
            }
        }
    }
    return objects;
}

//return an array of values that match on a certain key
function getValues(obj, key) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getValues(obj[i], key));
        } else if (i == key) {
            objects.push(obj[i]);
        }
    }
    return objects;
}

//return an array of keys that match on a certain value
function getKeys(obj, val) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getKeys(obj[i], val));
        } else if (obj[i] == val) {
            objects.push(i);
        }
    }
    return objects;
}

//http://techslides.com/how-to-parse-and-search-json-in-javascript	


var hasOwnProperty = Object.prototype.hasOwnProperty;

function isEmpty(obj) {

    // null and undefined are "empty"
    if (obj == null) return true;

    // Assume if it has a length property with a non-zero value
    // that that property is correct.
    if (obj.length > 0) return false;
    if (obj.length === 0) return true;

    // If it isn't an object at this point
    // it is empty, but it can't be anything *but* empty
    // Is it empty? Depends on your application.
    if (typeof obj !== "object") return true;

    // Otherwise, does it have any properties of its own?
    // Note that this doesn't handle
    // toString and valueOf enumeration bugs in IE < 9
    for (var key in obj) {
        if (hasOwnProperty.call(obj, key)) return false;
    }

    return true;
}


function* airportDetails(query) {


    if ((query.includes('what is the phone number of') || query.includes('what is the email address of') || query.includes('what is the phone number for') || query.includes('what is the email address for') || query.includes('what is the phone number of') || query.includes('what is the email address of') || query.includes('what is the phone number for') || query.includes('what is the email address for') || query.includes('what is the phone number of') || query.includes('what is the email address of') || query.includes('what is the phone number for') || query.includes('what is the email address for') || query.includes('tell me the phone number of') || query.includes('tell me the email address of') || query.includes('tell me the phone number for') || query.includes('tell me the email address for') || query.includes('tell me the phone number of') || query.includes('tell me the email address of') || query.includes('tell me the phone number for') || query.includes('tell me the email address for') || query.includes('tell me the phone number of') || query.includes('tell me the email address of') || query.includes('tell me the phone number for') || query.includes('tell me the email address for') || query.includes('What\'s the phone number of') || query.includes('What\'s the email address of') || query.includes('What\'s the phone number for') || query.includes('What\'s the email address for') || query.includes('What\'s the phone number of') || query.includes('What\'s the email address of') || query.includes('What\'s the phone number for') || query.includes('What\'s the email address for') || query.includes('What\'s the phone number of') || query.includes('What\'s the email address of') || query.includes('What\'s the phone number for') || query.includes('What\'s the email address for') || query.includes('get the phone number of') || query.includes('get the email address of') || query.includes('get the phone number for') || query.includes('get the email address for') || query.includes('get the phone number of') || query.includes('get the email address of') || query.includes('get the phone number for') || query.includes('get the email address for') || query.includes('get the phone number of') || query.includes('get the email address of') || query.includes('get the phone number for') || query.includes('get the email address for') || query.includes('get me the phone number of') || query.includes('get me the email address of') || query.includes('get me the phone number for') || query.includes('get me the email address for') || query.includes('get me the phone number of') || query.includes('get me the email address of') || query.includes('get me the phone number for') || query.includes('get me the email address for') || query.includes('get me the phone number of') || query.includes('get me the email address of') || query.includes('get me the phone number for') || query.includes('get me the email address for') || query.includes('tell the phone number of') || query.includes('tell the email address of') || query.includes('tell the phone number for') || query.includes('tell the email address for') || query.includes('tell the phone number of') || query.includes('tell the email address of') || query.includes('tell the phone number for') || query.includes('tell the email address for') || query.includes('tell the phone number of') || query.includes('tell the email address of') || query.includes('tell the phone number for') || query.includes('tell the email address for') || query.includes('phone number for') || query.includes('email address for') || query.includes('phone number of') || query.includes('email address of') || query.includes('what is the location of') || query.includes('what is the airport code of') || query.includes('what is the location for') || query.includes('what is the airport code for') || query.includes('what is the location of') || query.includes('what is the airport code of') || query.includes('what is the location for') || query.includes('what is the airport code for') || query.includes('what is the location of') || query.includes('what is the airport code of') || query.includes('what is the location for') || query.includes('what is the airport code for') || query.includes('tell me the location of') || query.includes('tell me the airport code of') || query.includes('tell me the location for') || query.includes('tell me the airport code for') || query.includes('tell me the location of') || query.includes('tell me the airport code of') || query.includes('tell me the location for') || query.includes('tell me the airport code for') || query.includes('tell me the location of') || query.includes('tell me the airport code of') || query.includes('tell me the location for') || query.includes('tell me the airport code for') || query.includes('What\'s the location of') || query.includes('What\'s the airport code of') || query.includes('What\'s the location for') || query.includes('What\'s the airport code for') || query.includes('What\'s the location of') || query.includes('What\'s the airport code of') || query.includes('What\'s the location for') || query.includes('What\'s the airport code for') || query.includes('What\'s the location of') || query.includes('What\'s the airport code of') || query.includes('What\'s the location for') || query.includes('What\'s the airport code for') || query.includes('get the location of') || query.includes('get the airport code of') || query.includes('get the location for') || query.includes('get the airport code for') || query.includes('get the location of') || query.includes('get the airport code of') || query.includes('get the location for') || query.includes('get the airport code for') || query.includes('get the location of') || query.includes('get the airport code of') || query.includes('get the location for') || query.includes('get the airport code for') || query.includes('get me the location of') || query.includes('get me the airport code of') || query.includes('get me the location for') || query.includes('get me the airport code for') || query.includes('get me the location of') || query.includes('get me the airport code of') || query.includes('get me the location for') || query.includes('get me the airport code for') || query.includes('get me the location of') || query.includes('get me the airport code of') || query.includes('get me the location for') || query.includes('get me the airport code for') || query.includes('tell the location of') || query.includes('tell the airport code of') || query.includes('tell the location for') || query.includes('tell the airport code for') || query.includes('tell the location of') || query.includes('tell the airport code of') || query.includes('tell the location for') || query.includes('tell the airport code for') || query.includes('tell the location of') || query.includes('tell the airport code of') || query.includes('tell the location for') || query.includes('tell the airport code for') || query.includes('location for') || query.includes('airport code for') || query.includes('location of') || query.includes('airport code of') || query.includes('what is the runway length of') || query.includes('how long is the runway length of') || query.includes('how many direct flights are there to') || query.includes('what is the where on earth id of') || query.includes('what is the runway length for') || query.includes('what is the where on earth id for') || query.includes('what is the runway length of') || query.includes('what is the where on earth id of') || query.includes('what is the runway length for') || query.includes('what is the where on earth id for') || query.includes('what is the runway length of') || query.includes('what is the where on earth id of') || query.includes('what is the runway length for') || query.includes('what is the where on earth id for') || query.includes('tell me the runway length of') || query.includes('tell me the where on earth id of') || query.includes('tell me the runway length for') || query.includes('tell me the where on earth id for') || query.includes('tell me the runway length of') || query.includes('tell me the where on earth id of') || query.includes('tell me the runway length for') || query.includes('tell me the where on earth id for') || query.includes('tell me the runway length of') || query.includes('tell me the where on earth id of') || query.includes('tell me the runway length for') || query.includes('tell me the where on earth id for') || query.includes('What\'s the runway length of') || query.includes('What\'s the where on earth id of') || query.includes('What\'s the runway length for') || query.includes('What\'s the where on earth id for') || query.includes('What\'s the runway length of') || query.includes('What\'s the where on earth id of') || query.includes('What\'s the runway length for') || query.includes('What\'s the where on earth id for') || query.includes('What\'s the runway length of') || query.includes('What\'s the where on earth id of') || query.includes('What\'s the runway length for') || query.includes('What\'s the where on earth id for') || query.includes('get the runway length of') || query.includes('get the where on earth id of') || query.includes('get the runway length for') || query.includes('get the where on earth id for') || query.includes('get the runway length of') || query.includes('get the where on earth id of') || query.includes('get the runway length for') || query.includes('get the where on earth id for') || query.includes('get the runway length of') || query.includes('get the where on earth id of') || query.includes('get the runway length for') || query.includes('get the where on earth id for') || query.includes('get me the runway length of') || query.includes('get me the where on earth id of') || query.includes('get me the runway length for') || query.includes('get me the where on earth id for') || query.includes('get me the runway length of') || query.includes('get me the where on earth id of') || query.includes('get me the runway length for') || query.includes('get me the where on earth id for') || query.includes('get me the runway length of') || query.includes('get me the where on earth id of') || query.includes('get me the runway length for') || query.includes('get me the where on earth id for') || query.includes('tell the runway length of') || query.includes('tell the where on earth id of') || query.includes('tell the runway length for') || query.includes('tell the where on earth id for') || query.includes('tell the runway length of') || query.includes('tell the where on earth id of') || query.includes('tell the runway length for') || query.includes('tell the where on earth id for') || query.includes('tell the runway length of') || query.includes('tell the where on earth id of') || query.includes('tell the runway length for') || query.includes('tell the where on earth id for') || query.includes('runway length for') || query.includes(' where on earth id for') || query.includes('runway length of') || query.includes(' where on earth id of') || query.includes('what is the time zone of') || query.includes('what is the latitude and longitude of') || query.includes('what is the time zone for') || query.includes('what is the latitude and longitude for') || query.includes('what is the time zone of') || query.includes('what is the latitude and longitude of') || query.includes('what is the time zone for') || query.includes('what is the latitude and longitude for') || query.includes('what is the time zone of') || query.includes('what is the latitude and longitude of') || query.includes('what is the time zone for') || query.includes('what is the latitude and longitude for') || query.includes('tell me the time zone of') || query.includes('tell me the latitude and longitude of') || query.includes('tell me the time zone for') || query.includes('tell me the latitude and longitude for') || query.includes('tell me the time zone of') || query.includes('tell me the latitude and longitude of') || query.includes('tell me the time zone for') || query.includes('tell me the latitude and longitude for') || query.includes('tell me the time zone of') || query.includes('tell me the latitude and longitude of') || query.includes('tell me the time zone for') || query.includes('tell me the latitude and longitude for') || query.includes('What\'s the time zone of') || query.includes('What\'s the latitude and longitude of') || query.includes('What\'s the time zone for') || query.includes('What\'s the latitude and longitude for') || query.includes('What\'s the time zone of') || query.includes('What\'s the latitude and longitude of') || query.includes('What\'s the time zone for') || query.includes('What\'s the latitude and longitude for') || query.includes('What\'s the time zone of') || query.includes('What\'s the latitude and longitude of') || query.includes('What\'s the time zone for') || query.includes('What\'s the latitude and longitude for') || query.includes('get the time zone of') || query.includes('get the latitude and longitude of') || query.includes('get the time zone for') || query.includes('get the latitude and longitude for') || query.includes('get the time zone of') || query.includes('get the latitude and longitude of') || query.includes('get the time zone for') || query.includes('get the latitude and longitude for') || query.includes('get the time zone of') || query.includes('get the latitude and longitude of') || query.includes('get the time zone for') || query.includes('get the latitude and longitude for') || query.includes('get me the time zone of') || query.includes('get me the latitude and longitude of') || query.includes('get me the time zone for') || query.includes('get me the latitude and longitude for') || query.includes('get me the time zone of') || query.includes('get me the latitude and longitude of') || query.includes('get me the time zone for') || query.includes('get me the latitude and longitude for') || query.includes('get me the time zone of') || query.includes('get me the latitude and longitude of') || query.includes('get me the time zone for') || query.includes('get me the latitude and longitude for') || query.includes('tell the time zone of') || query.includes('tell the latitude and longitude of') || query.includes('tell the time zone for') || query.includes('tell the latitude and longitude for') || query.includes('tell the time zone of') || query.includes('tell the latitude and longitude of') || query.includes('tell the time zone for') || query.includes('tell the latitude and longitude for') || query.includes('tell the time zone of') || query.includes('tell the latitude and longitude of') || query.includes('tell the time zone for') || query.includes('tell the latitude and longitude for') || query.includes(' time zone for') || query.includes('latitude and longitude for') || query.includes(' time zone of') || query.includes('latitude and longitude of') || query.includes('website of') || query.includes('what is the website of') || query.includes('what is the url of') || query.includes('what is the website for') || query.includes('what is the url for') || query.includes('what is the website of') || query.includes('what is the url of') || query.includes('what is the website for') || query.includes('what is the url for') || query.includes('what is the website of') || query.includes('what is the url of') || query.includes('what is the website for') || query.includes('what is the url for') || query.includes('tell me the website of') || query.includes('tell me the url of') || query.includes('tell me the website for') || query.includes('tell me the url for') || query.includes('tell me the website of') || query.includes('tell me the url of') || query.includes('tell me the website for') || query.includes('tell me the url for') || query.includes('tell me the website of') || query.includes('tell me the url of') || query.includes('tell me the website for') || query.includes('tell me the url for') || query.includes('What\'s the website of') || query.includes('What\'s the url of') || query.includes('What\'s the website for') || query.includes('What\'s the url for') || query.includes('What\'s the website of') || query.includes('What\'s the url of') || query.includes('What\'s the website for') || query.includes('What\'s the url for') || query.includes('What\'s the website of') || query.includes('What\'s the url of') || query.includes('What\'s the website for') || query.includes('What\'s the url for') || query.includes('get the website of') || query.includes('get the url of') || query.includes('get the website for') || query.includes('get the url for') || query.includes('get the website of') || query.includes('get the url of') || query.includes('get the website for') || query.includes('get the url for') || query.includes('get the website of') || query.includes('get the url of') || query.includes('get the website for') || query.includes('get the url for') || query.includes('get me the website of') || query.includes('get me the url of') || query.includes('get me the website for') || query.includes('get me the url for') || query.includes('get me the website of') || query.includes('get me the url of') || query.includes('get me the website for') || query.includes('get me the url for') || query.includes('get me the website of') || query.includes('get me the url of') || query.includes('get me the website for') || query.includes('get me the url for') || query.includes('tell the website of') || query.includes('tell the url of') || query.includes('tell the website for') || query.includes('tell the url for') || query.includes('tell the website of') || query.includes('tell the url of') ) && query.includes('airport')) {


        let country = "India";
        let airport = "India";

        let phoneNumber = "",
            email = "",
            url = "",
            location = "",
            airportCode = "",
            runwayLength = "",
            woeid = "",
            latlong = "",
            tz = "";


        let phoneNumberFlag = false,
            emailFlag = false,
            urlFlag = false,
            locationFlag = false,
            airportCodeFlag = false,
            runwayLengthFlag = false,
            woeidFlag = false,
            latlongFlag = false,
            tzFlag = false;


        console.log("hello " + airport);

        if (query.includes('phone number of')) {
            airport = query.split("of")[1].trim();
            console.log("hello222 " + airport);
            phoneNumberFlag = true;

        } else if (query.includes('email address of')) {
            airport = query.split("of")[1].trim();
            emailFlag = true;
        } else if (query.includes('location of')) {
            airport = query.split("of")[1].trim();
            locationFlag = true;
        } else if (query.includes('airport code of')) {
            airport = query.split("of")[1].trim();
            airportCodeFlag = true;
        } else if (query.includes('runway length of')) {
            airport = query.split("of")[1].trim();
            runwayLengthFlag = true;
        } else if (query.includes('where on earth id of')) {
            airport = query.split("of")[1].trim();
            woeidFlag = true;
        } else if (query.includes('latitude and longitude of')) {
            airport = query.split("of")[1].trim();
            latlongFlag = true;
        } else if (query.includes('time zone of')) {
            airport = query.split("of")[1].trim();
            tzFlag = true;
        } else if (query.includes('website of')) {
            airport = query.split("for")[1].trim();
            urlFlag = true;
        } else if (query.includes('url of')) {
            airport = query.split("for")[1].trim();
            urlFlag = true;
        } else if (query.includes('phone number for')) {
            airport = query.split("for")[1].trim();
            phoneNumberFlag = true;
        } else if (query.includes('email address for')) {
            airport = query.split("for")[1].trim();
            phoneNumberFlag = true;
        } else if (query.includes('location for')) {
            airport = query.split("for")[1].trim();
            locationFlag = true;
        } else if (query.includes('airport code for')) {
            airport = query.split("for")[1].trim();
            airportCodeFlag = true;
        } else if (query.includes('runway length for')) {
            airport = query.split("for")[1].trim();
            runwayLengthFlag = true;
        } else if (query.includes('where on earth id for')) {
            airport = query.split("for")[1].trim();
            woeidFlag = true;
        } else if (query.includes('latitude and longitude for')) {
            airport = query.split("for")[1].trim();
            latlongFlag = true;
        } else if (query.includes('time zone for')) {
            airport = query.split("for")[1].trim();
            tzFlag = true;
        } else if (query.includes('website for')) {
            airport = query.split("for")[1].trim();
            urlFlag = true;
        }else if (query.includes('url for')) {
            airport = query.split("for")[1].trim();
            urlFlag = true;
        }

        airport = airport.split("airport")[0].trim();

        airport = airport.charAt(0).toUpperCase() + airport.slice(1);


        console.log("airport: " + airport);

        var airportName = "";
        let data = yield require('./airport.json');

        //console.log(data);

        for (var key in data) {
            var value = data[key];
            //console.log(value.name.toString());
            airportName = value.name.toString();
            //console.log("airportName: "+airportName);	

            if (airportName.includes(airport)) {

                console.log("found");

                phoneNumber = value.phone.toString();
                console.log("phoneNumber: " + phoneNumber);
                email = value.email.toString();
                console.log("email: " + email);
                location = value.city.toString() + " belonging to the state of " + value.state.toString() + " in the country of " + value.country.toString();
                console.log("location: " + location);
                airportCode = value.code.toString() + " and International Civil Aviation Organization (ICAO) id " + value.icao.toString();
                console.log("airportCode: " + airportCode);
                runway_length = value.runway_length.toString() + " meters";
                console.log("runway_length: " + runway_length);
                woeid = value.woeid.toString();
                console.log("woeid: " + woeid);
                latlong = value.lat.toString() + " and longitude is " + value.lon.toString();
                console.log("latlong: " + latlong);
                tz = value.tz.toString();
                console.log("tz: " + tz);

                url = value.url.toString();
                console.log("url: " + url);

            }



        }


        airport = airport + " Airport";

        if (phoneNumber !== null && typeof phoneNumber !== 'object' && phoneNumberFlag == true) {

            return {
                text: airport + " Phone Number is " + phoneNumber
            }

        } else if (email !== null && typeof email !== 'object' && emailFlag == true) {

            return {
                text: airport + " Email Address is " + email
            }

        } else if (location !== null && typeof location !== 'object' && locationFlag == true) {

            return {
                text: airport + " is located at " + location
            }

        } else if (airportCode !== null && typeof airportCode !== 'object' && airportCodeFlag == true) {

            return {
                text: airport + " \'s  Airport Code is " + airportCode
            }

        } else if (runway_length !== null && typeof runway_length !== 'object' && runwayLengthFlag == true) {

            return {
                text: airport + " \'s  Runway length is " + runway_length
            }

        } else if (woeid !== null && typeof woeid !== 'object' && woeidFlag == true) {

            return {
                text: airport + " \'s  where on earth id is " + woeid
            }

        } else if (latlong !== null && typeof latlong !== 'object' && latlongFlag == true) {

            return {
                text: airport + " \'s  latitude is " + latlong
            }

        } else if (tz !== null && typeof tz !== 'object' && tzFlag == true) {

            return {
                text: airport + " \'s  time zone is " + tz
            }

        } else if (url !== null && typeof url !== 'object' && urlFlag == true) {

            return {
                text: airport + " \'s  website is " + url
            }

        }


    }


}

const intent = () => ({
    keywords: [""],
    module: 'countryAirport'
})

const examples = () => (
    []
)

module.exports = {
    get: airportDetails,
    hardRule
    //,examples
}
