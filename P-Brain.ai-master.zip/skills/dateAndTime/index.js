function hardRule(query, breakdown) {
    return query.startsWith("What is the date today") || query.startsWith("date") || query.startsWith("What is the date") || query.startsWith("date today") || query.startsWith("todays date") || query.startsWith("today date") || query.startsWith("Tell me the date today") || query.startsWith("Tell me the date") || query.startsWith("Tell me the date today") || query.startsWith("What is the day today") || query.startsWith("What is the day") || query.startsWith("day today") || query.startsWith("todays day") || query.startsWith("today day") || query.startsWith("Tell me the day today") || query.startsWith("Tell me the day") || query.startsWith("Tell me the day today") || query.startsWith("day")
}

function* date_Time(query) {
    let date = require('date-and-time');

    if (query.startsWith("What is the date today") || query.startsWith("date") || query.startsWith("What is the date") || query.startsWith("date today") || query.startsWith("todays date") || query.startsWith("today date") || query.startsWith("Tell me the date today") || query.startsWith("Tell me the date") || query.startsWith("Tell me the date today") || query.startsWith("What is the day today") || query.startsWith("What is the day") || query.startsWith("day today") || query.startsWith("todays day") || query.startsWith("today day") || query.startsWith("Tell me the day today") || query.startsWith("Tell me the day") || query.startsWith("Tell me the day today") || query.startsWith("day")) {

        let now = new Date();

        if (query.startsWith("date")) {

            return {
                text: 'Sir it\'s ' + date.format(now, 'dddd MMMM DD YYYY')
            }

        } else if (query.startsWith("day")) {

            return {
                text: 'Sir it\'s ' + date.format(now, 'dddd') + " today"
            }


        }



    }

}

const intent = () => ({
    keywords: ["What is the date today", "What is the date", "date today", "todays date", "today date", "Tell me the date today", "Tell me the date", "Tell me the date today", "What is the day today", "What is the day", "day today", "todays day", "today day", "Tell me the day today", "Tell me the day", "Tell me the day today"],
    module: 'dateAndTime'
})

const examples = () => (
    []
)

module.exports = {
    get: date_Time,
    hardRule,
    examples
}
