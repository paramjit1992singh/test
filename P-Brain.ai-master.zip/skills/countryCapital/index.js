function hardRule(query, breakdown) {
    return query.startsWith('what is the capital of') || query.startsWith('what is the capital of') || query.startsWith('what is the capital for') || query.startsWith('what is the capital for') || query.startsWith('what is the capital of') || query.startsWith('what is the capital of') || query.startsWith('what is the capital for') || query.startsWith('what is the capital for') || query.startsWith('what is the capital of') || query.startsWith('what is the capital of') || query.startsWith('what is the capital for') || query.startsWith('what is the capital for') || query.startsWith('tell me the capital of') || query.startsWith('tell me the capital of') || query.startsWith('tell me the capital for') || query.startsWith('tell me the capital for') || query.startsWith('tell me the capital of') || query.startsWith('tell me the capital of') || query.startsWith('tell me the capital for') || query.startsWith('tell me the capital for') || query.startsWith('tell me the capital of') || query.startsWith('tell me the capital of') || query.startsWith('tell me the capital for') || query.startsWith('tell me the capital for') || query.startsWith('What\'s the capital of') || query.startsWith('What\'s the capital of') || query.startsWith('What\'s the capital for') || query.startsWith('What\'s the capital for') || query.startsWith('What\'s the capital of') || query.startsWith('What\'s the capital of') || query.startsWith('What\'s the capital for') || query.startsWith('What\'s the capital for') || query.startsWith('What\'s the capital of') || query.startsWith('What\'s the capital of') || query.startsWith('What\'s the capital for') || query.startsWith('What\'s the capital for') || query.startsWith('get the capital of') || query.startsWith('get the capital of') || query.startsWith('get the capital for') || query.startsWith('get the capital for') || query.startsWith('get the capital of') || query.startsWith('get the capital of') || query.startsWith('get the capital for') || query.startsWith('get the capital for') || query.startsWith('get the capital of') || query.startsWith('get the capital of') || query.startsWith('get the capital for') || query.startsWith('get the capital for') || query.startsWith('get me the capital of') || query.startsWith('get me the capital of') || query.startsWith('get me the capital for') || query.startsWith('get me the capital for') || query.startsWith('get me the capital of') || query.startsWith('get me the capital of') || query.startsWith('get me the capital for') || query.startsWith('get me the capital for') || query.startsWith('get me the capital of') || query.startsWith('get me the capital of') || query.startsWith('get me the capital for') || query.startsWith('get me the capital for') || query.startsWith('tell the capital of') || query.startsWith('tell the capital of') || query.startsWith('tell the capital for') || query.startsWith('tell the capital for') || query.startsWith('tell the capital of') || query.startsWith('tell the capital of') || query.startsWith('tell the capital for') || query.startsWith('tell the capital for') || query.startsWith('tell the capital of') || query.startsWith('tell the capital of') || query.startsWith('tell the capital for') || query.startsWith('tell the capital for') || query.startsWith('capital for') || query.startsWith('capital for') || query.startsWith('capital of') || query.startsWith('capital of')

}




const request = require('co-request');

//return an array of objects according to key, value, or key and value matching
function getObjects(obj, key, val) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getObjects(obj[i], key, val));
        } else
            //if key matches and value matches or if key matches and value is not passed (eliminating the case where key matches but passed value does not)
            if (i == key && obj[i] == val || i == key && val == '') { //
                objects.push(obj);
            } else if (obj[i] == val && key == '') {
            //only add if the object is not already in the array
            if (objects.lastIndexOf(obj) == -1) {
                objects.push(obj);
            }
        }
    }
    return objects;
}

//return an array of values that match on a certain key
function getValues(obj, key) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getValues(obj[i], key));
        } else if (i == key) {
            objects.push(obj[i]);
        }
    }
    return objects;
}

//return an array of keys that match on a certain value
function getKeys(obj, val) {
    var objects = [];
    for (var i in obj) {
        if (!obj.hasOwnProperty(i)) continue;
        if (typeof obj[i] == 'object') {
            objects = objects.concat(getKeys(obj[i], val));
        } else if (obj[i] == val) {
            objects.push(i);
        }
    }
    return objects;
}

//http://techslides.com/how-to-parse-and-search-json-in-javascript	


var hasOwnProperty = Object.prototype.hasOwnProperty;

function isEmpty(obj) {

    // null and undefined are "empty"
    if (obj == null) return true;

    // Assume if it has a length property with a non-zero value
    // that that property is correct.
    if (obj.length > 0) return false;
    if (obj.length === 0) return true;

    // If it isn't an object at this point
    // it is empty, but it can't be anything *but* empty
    // Is it empty?  Depends on your application.
    if (typeof obj !== "object") return true;

    // Otherwise, does it have any properties of its own?
    // Note that this doesn't handle
    // toString and valueOf enumeration bugs in IE < 9
    for (var key in obj) {
        if (hasOwnProperty.call(obj, key)) return false;
    }

    return true;
}


function* countryInfo(query) {


    if (query.includes('what is the capital of') || query.includes('what is the capital of') || query.includes('what is the capital for') || query.includes('what is the capital for') || query.includes('what is the capital of') || query.includes('what is the capital of') || query.includes('what is the capital for') || query.includes('what is the capital for') || query.includes('what is the capital of') || query.includes('what is the capital of') || query.includes('what is the capital for') || query.includes('what is the capital for') || query.includes('tell me the capital of') || query.includes('tell me the capital of') || query.includes('tell me the capital for') || query.includes('tell me the capital for') || query.includes('tell me the capital of') || query.includes('tell me the capital of') || query.includes('tell me the capital for') || query.includes('tell me the capital for') || query.includes('tell me the capital of') || query.includes('tell me the capital of') || query.includes('tell me the capital for') || query.includes('tell me the capital for') || query.includes('What\'s the capital of') || query.includes('What\'s the capital of') || query.includes('What\'s the capital for') || query.includes('What\'s the capital for') || query.includes('What\'s the capital of') || query.includes('What\'s the capital of') || query.includes('What\'s the capital for') || query.includes('What\'s the capital for') || query.includes('What\'s the capital of') || query.includes('What\'s the capital of') || query.includes('What\'s the capital for') || query.includes('What\'s the capital for') || query.includes('get the capital of') || query.includes('get the capital of') || query.includes('get the capital for') || query.includes('get the capital for') || query.includes('get the capital of') || query.includes('get the capital of') || query.includes('get the capital for') || query.includes('get the capital for') || query.includes('get the capital of') || query.includes('get the capital of') || query.includes('get the capital for') || query.includes('get the capital for') || query.includes('get me the capital of') || query.includes('get me the capital of') || query.includes('get me the capital for') || query.includes('get me the capital for') || query.includes('get me the capital of') || query.includes('get me the capital of') || query.includes('get me the capital for') || query.includes('get me the capital for') || query.includes('get me the capital of') || query.includes('get me the capital of') || query.includes('get me the capital for') || query.includes('get me the capital for') || query.includes('tell the capital of') || query.includes('tell the capital of') || query.includes('tell the capital for') || query.includes('tell the capital for') || query.includes('tell the capital of') || query.includes('tell the capital of') || query.includes('tell the capital for') || query.includes('tell the capital for') || query.includes('tell the capital of') || query.includes('tell the capital of') || query.includes('tell the capital for') || query.includes('tell the capital for') || query.includes('capital for') || query.includes('capital for') || query.includes('capital of') || query.includes('capital of')) {


        let country = "India";


        if (query.includes('capital of')) {
            country = query.split("of")[1].trim();
        } else if (query.includes('capital for')) {
            country = query.split("for")[1].trim();
        }

        country = country.charAt(0).toUpperCase() + country.slice(1);
        console.log("country: " + country);

        if (country == 'America') {
            country = "United States of America";
        }

        const restcountries_url = 'https://restcountries.eu/rest/v2/name/' + country
        //const restcountries_url = 'https://restcountries.eu/rest/v2/name/' + country + '?fullText=true'
        let data = yield request(restcountries_url)
        data = JSON.parse(data.body)

        if (country == 'Uk') {
            country = "United Kingdom of Great Britain and Northern Ireland";
        } else if (country == 'Us' || country == 'Usa' || country == 'America') {
            country = "United States of America";
        }

        console.log("hii: " + isEmpty(getObjects(data, 'name', country)));

        console.log("hii222222222222: " + typeof getObjects(data, 'name', country));
        if (isEmpty(getObjects(data, 'name', country))) {
            console.log("empty");


        }


        let data2 = getObjects(data, 'name', country);
        console.log("hii2: " + isEmpty(getObjects(data2, 'name', country)));
        console.log("hii33333333333333333: " + typeof getObjects(data2, 'name', country));

        if (isEmpty(getObjects(data2, 'name', country))) {
            console.log("empty");
        }

        let data3 = getObjects(data2, 'name', country);
        var countryCapital;

        for (var key in data3) {
            var value = data3[key];
            console.log(value.capital.toString());
            countryCapital = value.capital.toString();
        }




        if (countryCapital !== null && typeof countryCapital !== 'object') {

            return {
                text: "Capital of " + country + " is " + countryCapital
            }

        }

    }


}

const intent = () => ({
    keywords: ["dialing calling"],
    module: 'countryCapital'
})

const examples = () => (
    []
)

module.exports = {
    get: countryInfo,
    hardRule
    //,examples
}
