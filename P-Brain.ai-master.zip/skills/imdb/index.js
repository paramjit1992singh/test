const imdb = require('imdb-api');

function * imdbData() {

imdb.get('The Toxic Avenger', {apiKey: 'foo', timeout: 30}).then(console.log).catch(console.log);
imdb.getById('tt0090190', {apiKey: 'foo', timeout: 30}).then(console.log).catch(console.log);
imdb.getReq({ name: 'The Toxic Avenger', opts: {apiKey: 'foo', timeout: 30} }).then(console.log).catch(console.log);
	
    return {text: 'Hello World'}
}

const intent = () => ({
    keywords: [], module: 'imdb'
})

const examples = () => (
    []
)

module.exports = {
    get: imdbData,
    intent,
    examples
}
