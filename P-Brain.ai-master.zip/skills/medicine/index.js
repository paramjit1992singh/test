function * medicine_resp() {

var request = require('request');

var accessToken = '9545c7a36362fb33f490428f7994d496e0dcfbf000027a662d3f4eec5c77a363 ';

request({
  url: 'http://www.healthos.co/api/v1/search/medicines/brands/{{headache}}',
  auth: {
    'bearer': accessToken
  }
}, function(err, res) {
  console.log(res.body);
});    



return {text: 'Hello World'}
}

const intent = () => ({
    keywords: ["medicine"], module: 'medicine'
})

const examples = () => (
    []
)

module.exports = {
    get: medicine_resp,
    intent,
    examples
}
